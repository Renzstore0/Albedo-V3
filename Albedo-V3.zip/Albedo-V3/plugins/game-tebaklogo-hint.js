let handler = async (m, { conn }) => {
    conn.tebaklogo = conn.tebaklogo ? conn.tebaklogo : {}
    let id = m.chat
    if (!(id in conn.tebaklogo)) throw false
    let json = conn.tebaklogo[id][1]
    m.reply('*Clue:* ' + '```' + json.hasil.data.jawaban.replace(/[AIUEOaiueo]/ig, '_') + '```' + '\n\n*Jangan Balas Chat Ini Tapi Balas Soalnya*')
}
handler.command = /^hgo$/i

handler.limit = true

export default handler