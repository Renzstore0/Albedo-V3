let handler = async (m, { conn, usedPrefix }) => conn.sendButton(m.chat, `“${pantun.getRandom()}”`, author, ['Pantun', `${usedPrefix}pantun`], m)

handler.help = ['pantun']
handler.tags = ['quotes']
handler.command = /^(pantun)$/i

export default handler


// https://jalantikus.com/tips/kata-kata-bucin/
const pantun = [
"Laki-laki itu bukan saya\ntetapi itu adalah sahabatku\nBapak kamu seorang pencuri ya\nsoalnya kau telah mencuri hatiku",
"Satu titik dua koma.\nSi cantik ada yang punya.",
"Air cuka air mata.\nAku suka kamu cinta.",
"Baju batik di atas pohon.\nHai, kamu yang cantik godain aku, dong.",
"Burung kutilang makan pepaya.\nKamu yang cantik, siapa yang punya.",
"Roti busuk dalam penjara.\nHatiku tertusuk panah asmara.",
"Haus minum, badan segar.\nKamu tersenyum hatiku bergetar.",
"Bertamu bawa ikan.\nSenyummu takkan kulupakan.",
"Ikan hiu bawa guling.\nI love you darling.",
"Dua tiga burung merpati.\nKu cinta kau sampai mati.",
"Beli buku buat tamu.\nSejuk hatiku melihat senyummu.",
"Ikan gabus di rawa-rawa\nIkan belut nyangkut di jaring\nPerutku sakit menahan tawa\nGigi palsu meloncat ke piring",
"Kereta lewat terowongan\nSelanjutnya lewan rutan\nJangan kamu gelantungan\nItu mirip orang hutan",
"Pergi wisata naik kapal\nKapalnya kapal feri\nJadi anak jangan nakal\nNanti teman pada lari",
"Pak tani ke ladang membawa karung\nDibawanya dengan jemari\nWajah kamu jarang murung\nKayak belum makan tiga hari",
"Besok pagi menebang pohon sagu\nMemotongnya dengan parang\nApa kamu masih meragu\nAku ini milikmu seorang",
"Seorang anak berbaju basah\nSedang naik seekor kuda\nHidup ini sudah susah\nApalagi jika kamu tak ada",
"Seekor kuda sedang berlari\nMelintasi gedung olahraga\nMelihat kamu senyum sendiri\nAku jadi mulai curiga.",
"Melihat rusa pergi berlari\nKe arah hutan yang sepi\nBangun, hari sudah pagi\nWaktunya mewujudkan mimpi",
"Pakai handbody merk marina\nSebelum hendak pergi kerja\nKenapa hidupmu sungguh merana\nMungkin karena bekerja",
"Bibi berkunjung membawa bawang\nDiletakkan di atas meja\nDari mana dapat uang\nKalau kamu tidak bekerja",
"Seorang raja bersama pengawal\nPergi berburu naik kuda\nJika ingin tidak menyesal\nJangan malas selagi muda",
"Main ke rumah teman pinjam gasing\nRumahnya ada di tengah kota\nSetiap orang punya jalan suksesnya masing-masing\nJalani saja dan fokus pada jalan kita",
"Jalan-jalan ke Bekasi\nBeli odeng lima ribuan\nJangan lupa makan-makanan bergizi\nUntuk menjaga kesehatan",
"Pake gincu, pergi ke pasar\nKamu lucu, kalau lagi lapar",
"Good morning, selamat pagi\nHai yang pakai baju pink, kenalan yuk sini",
"Pohon pisang daunnya layu\nBisa dijadikan pupuk di sawah\nSaat abang bilang i laph yu\nKu cuma bisa bilang, cius miapah",
"Naik delman\nMau ke taman\nDia tampan\nTapi sayang, jerawatan",
"Bola pingpong\nDimakan gelatik\nBiar ompong\nYang penting cantik",
"Ajak pacar makan di restauran\nBertemu mantan yang sekarang teman\nHati bingung dan gak karuan\nTernyata mantan minta balikan",
"Wajahmu memang imut\nBodymu kecil kaya siput\nTingkahmu membuatku salut\nTapi sayang hobimu kentut",
"Aku dukung Korea Selatan\nKamu dukung Jepang\nWalaupun kita mantan\nTapi aku masih tetap sayang",
"Pergi ke kota Tuban\nBuat beli buah rambutan\nMantan udah masuk pelaminan\nKenapa kamu masih sendirian",
"Buah mangga buah kedondong\nBuah nanas buah apel\nbuah manggis buah durian\nItulah nama buah-buahan",
"Dari Mampang nemu kaca\nDaun kelor rasa ketan\nLiat aja tampang yang baca\nUdah kayak kolor Setan",
"Hujan di Solo\nBanjir di Semarang\nKasihan deh lo\nMasih jomblo sampe sekarang",
"Aku Indonesia\nKamu Pakistan\nAku hanya orang biasa\nYang membutuhkan perhatian",
"Narok uang di dalam saku\nSakunya robek gara-gara kuku\nJangan sampai ko menghianatiku\nKarena hanya kau yang selalu ada di hatiku",
"Kalau pergi ke negeri Arab\nBelikan saya sebuah kitab\nPerempuan masa kini gak bisa diharap\nBodi bolehlah tapi betis hemm berkurap",
"Kalau hendak berlayar sampai ketepian\nHari ini cuacanya berawan\nPaling gak enak hidup sendirian\nSaran gue cepat nikahan",
"Ikan cantik ya ikan lohan\nDurian dibikin bolu\nLaki-laki yang ga tampan\nEeh kasihan deh lu",
"Tempayan tutupnya miring\nAnak perawan kentutnya nyaring\nYang janda kentutnya semriwing\nYang bencog kentutnya garing",
"Buah pisang buat tomat\nDisimpan di dalam lumbung padi\nPantas baunya menyengat\nTernyata kamu belum mandi",
"Lagi kepepet hilang dompet\nPijem duit pasti dapet\nPutih kecil jalannya cepet\nNasi putih nempel di jet",
"Ketemu angkatan bawa senjata\nAngkatan bernama abang poltak\nSi adik manis memang cantik jelita\nTapi sayang ketawanya kok seperti kuntilanak",
"Buat jus si buah naga\nKasih susu cap bendera di atasnya\nHati hati pria pria yang hobi menggoda\nKarena biasanya mereka itu dari spesies buaya",
"Saat aku sakit\nTidak lupa kau bawakan bunga\nSaat kau terbelit-belit\nHati terasa merana",
]