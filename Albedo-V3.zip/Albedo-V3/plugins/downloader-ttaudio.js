import fetch from 'node-fetch'
import axios from 'axios'
import fs from 'fs'

let handler = async (m, { conn, args }) => {
  if (!args[0]) throw 'Uhm...url nya mana?'
  m.reply('Sedang Mendownload...')
  let url = `https://api.lolhuman.xyz/api/tiktokmusic?apikey=RyHar&url=${args[0]}`
  await conn.sendFile(m.chat, url, 'xynz.opus', '', m, false)
}

handler.help = ['tiktokaudio <link>']
handler.tags = ['downloader']
handler.command = /^(tt|tiktok)(a(udio)?|mp3|sound)(dl)?(download(er)?)?$/i
handler.limit = true

export default handler
