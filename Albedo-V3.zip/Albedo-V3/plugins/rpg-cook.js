let handler = async (m, {
	command,
	usedPrefix,
	DevMode,
	args
}) => {
	let type = (args[0] || '').toLowerCase()
    let msk = (args[0] || '').toLowerCase()
    let user = global.db.data.users[m.sender]
    let author = global.author
let cok = `
*Seafood*
▧ Kepiting Bakar 🦀
〉Need 2 Kepiting 🦀 & 1 Coal 🕳️
▧ Lobster Saus Tiram 🦞
〉Need 2 Lobster 🦞 & 1 Coal 🕳️
▧ Cumi Balado 🦑
〉Need 2 Cumi 🦑 & 1 Coal 🕳️
▧ Gurita Bakar 🐙
〉Need 2 🐙 & 1 Coal 🕳️
▧ Sushi Dory 🐠
〉Need 2 Dory 🐠 & 1 Coal 🕳️

*Meat Food*
▧ Steak Sapi 🐄
〉Need 2 Sapi 🐄 & 1 Coal 🕳️
▧ Babi Guling 🐖
〉Need 2 Babi 🐖 & 1 Coal 🕳️
▧ Sate Ayam 🐓
〉Need 2 Ayam 🐓 & 1 Coal 🕳️
▧ Sate Kambing 🐐
〉Need 2 Kambing 🐐 & 1 Coal 🕳️
▧ Rendang Buaya 🐊
〉Need 2 Buaya 🐊 & 1 Coal 🕳️
`

try {
       if (/masak|cook/i.test(command)) {
            const count = args[1] && args[1].length > 0 ? Math.min(5, Math.max(parseInt(args[1]), 1)) : !args[1] || args.length < 3 ? 1 : Math.min(1, count)
            switch (type) {
            	case 'kepitingbakar':
            if (user.kepiting < count * 2 || user.coal < 1 * count) {
                           user.kepiting >= count * 1
                            user.kepiting -= count * 2
                            user.coal -= count * 1
                            user.kepitingbakar += count * 1
                            conn.reply(m.chat, `Sukses memasak ${count} Kepiting Bakar🦀`, m)
                       } else conn.reply(m.chat, `Anda tidak memiliki bahan untuk memasak 🦀\nAnda butuh 2 Kepiting dan 1 coal untuk memasak`, m)
					break
				  case 'lobstersaustiram':
            if (user.lobster < count * 2 || user.coal < 1 * count) {
                            user.lobster >= count * 1
                            user.lobster -= count * 2
                            user.lobster -= count * 1
                            user.lobstersaustiram += count * 1
                            conn.reply(m.chat, `Sukses memasak ${ count } Lobster Saus Tiram🦞`, m)
                       } else conn.reply(m.chat, `Anda tidak memiliki bahan untuk memasak 🦞\nAnda butuh 2 Lobster dan 1 coal untuk memasak`, m)
					break
                  case 'cumibalado':
            if (user.cumi < count * 2 || user.coal < 1 * count) {
                            user.cumi >= count * 1
                            user.cumi -= count * 2
                            user.coal -= count * 1
                            user.cumibalado += count * 1
                            conn.reply(m.chat, `Sukses memasak ${ count } Cumi Balado🦑`, m)
                       } else conn.reply(m.chat, `Anda tidak memiliki bahan untuk memasak dimasak 🦑\nAnda butuh 2 Cumi dan 1 coal untuk memasak`, m)
					break
                   case 'guritabakar':
            if (user.gurita < count * 2 || user.coal < 1 * count) {
                           user.gurita >= count * 1
                            user.gurita -= count * 2
                            user.coal -= count * 1
                            user.guritabakar += count * 1
                            conn.reply(m.chat, `Sukses memasak ${ count } Gurita Bakar🐙`, m)
                       } else conn.reply(m.chat, `Anda tidak memiliki bahan untuk memasak 🐙\nAnda butuh 2 Gurita dan 1 coal untuk memasak`, m)
					break
                        case 'sushidory':
            if (user.dory < count * 2 || user.coal < 1 * count) {
                          user.dory >= count * 1
                            user.dory -= count * 2
                            user.coal -= count * 1
                            user.sushidory += count * 1
                            conn.reply(m.chat, `Sukses memasak ${ count } Sushi Dory🐠`, m)
                       } else conn.reply(m.chat, `Anda tidak memiliki bahan untuk memasak 🐠\nAnda butuh 2 Dory dan 1 coal untuk memasak`, m)
					break
                        case 'steaksapi':
            if (user.sapi < count * 2 || user.coal < 1 * count) {
                            user.sapi >= count * 1
                            user.sapi -= count * 2
                            user.coal -= count * 1
                            user.steaksapi += count * 1
                            conn.reply(m.chat, `Sukses memasak ${ count } Steak Sapi🐄`, m)
                       } else conn.reply(m.chat, `Anda tidak memiliki bahan untuk memasak steak\nAnda butuh 2 sapi dan 1 coal untuk memasak`, m)
				break
             case 'babiguling':
            if (user.babi < count * 2 || user.coal < 1 * count) {
                            user.babi >= count * 1
                            user.babi -= count * 2
                            user.coal -= count * 1
                            user.babiguling += count * 1
                            conn.reply(m.chat, `Sukses memasak ${ count } Babi Guling🐖`, m)
                       } else conn.reply(m.chat, `Anda tidak memiliki bahan untuk memasak 🐖\nAnda butuh 2 babi dan 1 coal untuk memasak`, m)
				break
				case 'sateayam':
            if (user.ayam < count * 2 || user.coal < 1 * count) {
                           user.ayam >= count * 1
                            user.ayam -= count * 2
                            user.coal -= count * 1
                            user.sateayam += count * 1
                            conn.reply(m.chat, `Sukses memasak ${count} Sate Ayam🐓`, m)
                       } else conn.reply(m.chat, `Anda tidak memiliki bahan untuk memasak 🐓\nAnda butuh 2 Ayam dan 1 coal untuk memasak`, m)
					break
					case 'satekambing':
            if (user.kambing < count * 2 || user.coal < 1 * count) {
                           user.kambing >= count * 1
                            user.kambing -= count * 2
                            user.coal -= count * 1
                            user.satekambing += count * 1
                            conn.reply(m.chat, `Sukses memasak ${count} Sate Kambing🐐`, m)
                       } else conn.reply(m.chat, `Anda tidak memiliki bahan untuk memasak 🐐\nAnda butuh 2 Kambing dan 1 coal untuk memasak`, m)
					break
					case 'rendangbuaya':
            if (user.buaya < count * 2 || user.coal < 1 * count) {
                           user.buaya >= count * 1
                            user.buaya -= count * 2
                            user.coal -= count * 1
                            user.rendangbuaya += count * 1
                            conn.reply(m.chat, `Sukses memasak ${count} Rendang Buaya🐊`, m)
                       } else conn.reply(m.chat, `Anda tidak memiliki bahan untuk memasak 🐊\nAnda butuh 2 Buaya dan 1 coal untuk memasak`, m)
					break
                default:
                await conn.sendMessage(m.chat, {
				text: cok,
				footer: author,
				title: '「 *C O O K I N G* 」',
				buttonText: "C O O K I N G",
				sections: [{
					title: "List Featured",
					rows: [{
				title: "Kepiting Bakar 🦀",
				rowId: ".cook kepitingbakar",
				description: "Memasak Kepiting"
			},{
				title: "Lobster Saus Tiram🦞",
				rowId: ".cook lobstersaustiram",
				description: "Memasak Lobster"
			},{
				title: "Cumi Balado🦑",
				rowId: ".cook cumibalado",
				description: "Memasak Cumi"
			},{
				title: "Gurita Bakar🐙",
				rowId: ".cook guritabakar",
				description: "Memasak Gurita"
			},{
				title: "Sushi Dory🐠",
				rowId: ".cook sushidory",
				description: "Memasak Dory"
			},{
				title: "Steak Sapi🐄",
				rowId: ".cook steaksapi",
				description: "Memasak Sapi"
			},{
				title: "Babi Guling🐖",
				rowId: ".cook babiguling",
				description: "Memasak Babi"
			},{
				title: "Sate Ayam🐓",
				rowId: ".cook sateayam",
				description: "Memasak Ayam"
			},{
				title: "Sate Kambing🐐",
				rowId: ".cook satekambing",
				description: "Memasak Kambing"
			},{
				title: "Rendang Buaya🐊",
				rowId: ".cook rendangbuaya",
				description: "Memasak Buaya"
			}
					]
				}]
			})
            }
        }
    } catch (e) {
        conn.reply(m.chat, `Sepertinya ada yg eror,coba laporin ke owner deh`, m)
        console.log(e)
        if (DevMode) {
            for (let jid of global.owner.map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').filter(v => v != conn.user.jid)) {
                conn.sendMessage(jid, 'shop.js error\nNo: *' + m.sender.split`@`[0] + '*\nCommand: *' + m.text + '*\n\n*' + e + '*', MessageType.text)
            }
        }
    }
}

handler.help = ['masak <masakan> <args>', 'cook <masakan> <args>']
handler.tags = ['rpg']
handler.command = /^(masak|cook)$/i

export default handler