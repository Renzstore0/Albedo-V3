import fetch from 'node-fetch'

let handler = async (m, { conn, command }) => {
	let url = 'https://api.lolhuman.xyz/api/random/quotesimage?apikey=RyHar'
	conn.sendButton(m.chat, 'Quotes Hari Ini...', wm, await(await fetch(url)).buffer(), [['N E X T',`.${command}`]],m)
}
handler.command = /^(qimage)$/i
handler.tags = ['quotes']
handler.help = ['qimage']
handler.premium = false
handler.limit = true

export default handler