import fetch from 'node-fetch'
let handler = async (m, { text }) => {
	try {
	if (!text) throw 'Apa Nama Characternya?'
	let apa = await fetch(`https://saipulanuar.ga/api/info/genshin?query=${text}`)
	let apatuh = await apa.json()
	let tuh = apatuh.result
	let teks = `
🎭 *Name:* ${tuh.name}
🎨 *FullName:* ${tuh.fullname}
🎗 *Gender:* ${tuh.gender}
👣 *Body:* ${tuh.body}
🎐 *Tittle:* ${tuh.title}
⏰ *BirtDay:* ${tuh.birthday}
🌟 *Constellation:* ${tuh.constellation}

⚔️ *Weapon:* ${tuh.weapontype}
🔮 *Element:* ${tuh.element}
🛡 *Substat:* ${tuh.substat}
🧭 *Region:* ${tuh.region}

🗣️ *Cv:*
*English:* ${tuh.cv.english}
*Chinese:* ${tuh.cv.chinese}
*Japanese:* ${tuh.cv.japanese}
*Korean:* ${tuh.cv.korean}

📝 *Deskripsion:* ${tuh.description}
`

await conn.sendButton(m.chat, '*–––––『𝙲𝙷𝙰𝚁𝙰𝙲𝚃𝙴𝚁』–––––*', teks, await(await fetch(tuh.images.cover1)).buffer(), [['Donasi', '.donasi']], m)
} catch (e) {
	throw 'Character Tidak Ditemukan'
	}
}
handler.help = ['charagenshin']
handler.command = /^charagi|charagenshin|genshinchar|genshinchara$/i
handler.tags = ['internet']
handler.limit = true
export default handler 