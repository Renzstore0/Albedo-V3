import fetch from 'node-fetch'
let handler = async(m, { conn, usedPrefix, text, args, command }) => {
    if (!text) throw `Uhm.. Teksnya mana?`
    
let res = await fetch(`https://api.lolhuman.xyz/api/primbon/artimimpi?apikey=${global.lolkey}&query=${text}`)
  let x = await res.json()
  await conn.sendButton(m.chat, `${x.result}`, wm, null, [['Search!', `${usedPrefix + command}`]], m)
}
handler.help = ['artimimpi'].map(v => v + ' <text>')
handler.tags = ['internet']
handler.command = /^artimimpi$/i
export default handler
