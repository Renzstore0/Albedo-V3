import fs from 'fs'
let handler = async (m, { conn  }) => {
m.reply('⚘ ᴄʀᴇᴀᴛᴇ ʙʏ ʀᴇɴᴢ')
let vn = fs.readFileSync('./mp3/AUD-20221216-WA0311.m4a')
await conn.sendFile(m.chat, vn, 'error.mp3', null, m, true)
}

handler.command = handler.help = ['ara-ara-onichan']
handler.tags = ['random']

export default handler
