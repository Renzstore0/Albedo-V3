import fetch from 'node-fetch'
import uploadImage from '../lib/uploadImage.js'
let handler = async (m, { conn, usedPrefix, command }) => {
  let q = m.quoted ? m.quoted : m
  let mime = (q.msg || q).mimetype || ''
  if (!mime) throw 'Fotonya Mana? Reply gambar yg gk ada button aja'
  if (!/image\/(jpe?g|png)/.test(mime)) throw `Tipe ${mime} tidak didukung!`
  let img = await q.download?.()
  let url = await uploadImage(img)
  let f = await fetch(`https://api.lolhuman.xyz/api/agedetect?apikey=${global.lolkey}&img=${url}`)
  let x = await f.json()
  let caption = `*Umurmu:* ${x.result}`
await conn.sendButton(m.chat, caption, wm, null, [['Search!', `${usedPrefix + command}`]], m)
}
handler.help = ['agedetect']
handler.tags = ['fun']
handler.command = /^(agedetect|agedetection)$/i

handler.limit = true

export default handler