import fetch from 'node-fetch'
import uploadImage from '../lib/uploadImage.js'
let handler = async (m, { conn, usedPrefix, command }) => {
  let q = m.quoted ? m.quoted : m
  let mime = (q.msg || q).mimetype || ''
  if (!mime) throw 'Fotonya Mana? Reply gambar yg gk ada button aja'
  if (!/image\/(jpe?g|png)/.test(mime)) throw `Tipe ${mime} tidak didukung!`
  let img = await q.download?.()
  let url = await uploadImage(img)
  let f = `https://api.lolhuman.xyz/api/facedetect?apikey=${global.lolkey}&img=${url}`
  let caption = `Ini Dia Kak...`
await conn.sendButton(m.chat, caption, wm, await(await fetch(f)).buffer(), [['Search!', `${usedPrefix + command}`]], m)
}
handler.help = ['facedetect']
handler.tags = ['tools']
handler.command = /^(facedetect)$/i

handler.limit = true

export default handler