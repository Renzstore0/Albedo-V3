import fetch from 'node-fetch'

let handler = async (m, { conn, command }) => {
	let url = await fetch('https://api.lolhuman.xyz/api/pinterest?apikey=RyHar&query=asuna')
	let image = await url.json()
	conn.sendButton(m.chat, 'Waifu nya om (≧ω≦)', wm, await(await fetch(image.result)).buffer(), [['🔁Next🔁',`.${command}`]],m)
}
handler.command = /^(asuna)$/i
handler.tags = ['anime']
handler.help = ['asuna']
handler.premium = false
handler.limit = true

export default handler