import fetch from 'node-fetch'
let handler = async (m, { conn, args, usedPrefix }) => {
   let response = args.join(' ').split('|')
  if (!args[0]) throw `ᴍᴀꜱᴜᴋᴋᴀɴ ᴛᴇxᴛ\n Contoh: \n${usedPrefix}ktp nik|prov|kabu|nama|ttl|jk|jl|lurah|camat|agama|nikah|kerja|warga|until|img`
  m.reply('ᴘʀᴏꜱᴇꜱ...')
  
  let res = `https://api.lolhuman.xyz/api/ktpmaker?apikey=RyHar&nik=${response[0]}&prov=${response[1]}&kabu=${response[2]}&name=${response[3]}&ttl=${response[4]}&jk=${response[5]}&jl=${response[6]}&lurah=${response[7]}&camat=${response[8]}&agama=${response[9]}&nikah=${response[10]}&kerja=${response[11]}&warga=${response[12]}&until=${response[13]}&img=${response[14]}`
  conn.sendFile(m.chat, res, 'xynz.jpg', `ꜱᴜᴅᴀʜ ᴊᴀᴅɪ`, m, false)
}
handler.help = ['ktp'].map(v => v + ' <text>')
handler.tags = ['nulis']
handler.command = /^(ktp)$/i

handler.premium = true

export default handler