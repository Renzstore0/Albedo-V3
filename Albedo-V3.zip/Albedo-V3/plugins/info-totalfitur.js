import fs from 'fs'
import fetch from 'node-fetch'
import moment from 'moment-timezone'
let handler = async (m, { conn, args, command }) => {
	let floc = {
            key:
            { fromMe: false,
            participant: `0@s.whatsapp.net`, ...(m.chat  ? 
            { remoteJid: "status@broadcast" } : {}) },
            message: { "liveLocationMessage": { "caption":"Aktif","h": `${wm}`, 'jpegThumbnail': fs.readFileSync('./thumbnail.jpg')}}
           }
let imgr = elainajpg.getRandom()
let d = new Date(new Date + 3600000)
    let locale = 'id'
    // d.getTimeZoneOffset()
    // Offset -420 is 18.00
    // Offset    0 is  0.00
    // Offset  420 is  7.00
    let weton = ['Pahing', 'Pon', 'Wage', 'Kliwon', 'Legi'][Math.floor(d / 84600000) % 5]
    let week = d.toLocaleDateString(locale, { weekday: 'long' })
    let date = d.toLocaleDateString(locale, {
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    })
    let wibh = moment.tz('Asia/Jakarta').format('HH')
    let wibm = moment.tz('Asia/Jakarta').format('mm')
    let wibs = moment.tz('Asia/Jakarta').format('ss')
    let wktuwib = `${wibh} H ${wibm} M ${wibs} S`
let totalf = Object.values(global.plugins).filter(
    (v) => v.help && v.tags
  ).length;
  let buttonMessage= {
'document':{'url':sgc},
'mimetype':global.ddocx,
'fileName': wm,
'fileLength':fsizedoc,
'pageCount':fpagedoc,
'contextInfo':{
'forwardingScore':555,
'isForwarded':true,
'externalAdReply':{
"mediaUrl": hwaifu.getRandom(),
'mediaType':1,
'sourceId': 'Tes',
"containsAutoReply": true,
"showAdAttribution": true,
'renderLargerThumbnail': true,
'previewType':'pdf',
'title': 'T O T A L  F I T U R',
'body': '',
'thumbnail':await(await fetch('https://telegra.ph/file/628edb79174e46eabf7a7.jpg')).buffer(),
'sourceUrl': ''}},
'caption': `Total Fitur Bot Saat ini: ${totalf}\n`,
'footer': wm,
'buttons':[
{'buttonId':'.menu','buttonText':{'displayText':'Mᴇɴᴜ'},'type':1},
{'buttonId':'.donasi','buttonText':{'displayText':'Dᴏɴᴀsɪ'},'type':1}
],
}
    await conn.sendMessage(m.chat,buttonMessage, { quoted: floc, mentions: [m.sender] })
 
}


handler.help = ['totalfitur']
handler.tags = ['info']
handler.command = ['totalfitur']
export default handler