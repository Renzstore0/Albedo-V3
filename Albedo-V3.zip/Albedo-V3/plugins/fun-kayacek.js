let handler  = async (m, { conn }) => {
  conn.reply(m.chat,`“${pickRandom(global.kaya)}”`, m)
}
handler.help = ['kayacek']
handler.tags = ['game']
handler.command = /^(kayacek)$/i
handler.owner = false
handler.mods = false
handler.premium = false
handler.group = false
handler.private = false

handler.admin = false
handler.botAdmin = false

handler.fail = null
handler.limit = true

export default handler 

function pickRandom(list) {
  return list[Math.floor(list.length * Math.random())]
}

global.kaya = [
'📮Kaya Level : 4%\n\nJir miskin amat lu',
'📮Kaya Level : 7%\n\nSerius ya Bro,, Lu Terlalu Miskin!',
'📮Kaya Level : 12%\n\nMakin lama gw jijik liat lo gara-gara miskin!',
'📮Kaya Level : 22%\n\nGembel lu ya😂',
'📮Kaya Level : 27%\n\nKeknya hidul lu baka miskin,, berdoa aja',
'📮Kaya Level : 35%\n\nYang sabar ya miskin',
'📮Kaya Level : 41%\n\nSemoga diberkati supaya kaya',
'📮Kaya Level : 48%\n\nDijamin hidup lu gak bakalan senang',
'📮Kaya Level : 56%\n\nLumayan Kaya Juga Lu',
'📮Kaya Level : 64%\n\nLumayan lah',
'📮Kaya Level : 71%\n\nMulai kaya juga lu',
'📮Kaya Level : 1%\n\nAWOAKAK MISKIIIN!!!',
'📮Kaya Level : 1%\n\nAWOAKAK MISKIIIN!!!',
'📮Kaya Level : 77%\n\nGak akan Salah Lagi dah Sultan',
'📮Kaya Level : 83%\n\nDijamin Lu akan Sultan',
'📮Kaya Level : 89%\n\nPara sultan pesti pengen jadi teman lo!',
'📮Kaya Level : 94%\n\nSULTAAAAAAAAN!!!',
'📮Kaya Level : 100%\n\nLU EMANG ORANG PALING SULTAN DI DUNIA, KAYA OWNER:v',
]