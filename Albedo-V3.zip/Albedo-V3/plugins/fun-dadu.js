import { Sticker } from 'wa-sticker-formatter'
let handler = async (m, { conn }) => {
let dadu = 'https://api.lolhuman.xyz/api/sticker/dadu?apikey=RyHar'
let stiker = await createSticker(dadu, false, stickpack, stickauth)
conn.sendFile(m.chat, stiker, 'sticker.webp', '', m)
}
handler.help = ['dadu']
handler.tags = ['game']
handler.command = ['dadu'] 
export default handler
async function createSticker(dadu, url, packName, authorName, quality) {
	let stickerMetadata = {
		type: 'full',
		pack: stickpack,
		author: stickauth,
		quality
	}
	return (new Sticker(dadu ? dadu : url, stickerMetadata)).toBuffer()
}