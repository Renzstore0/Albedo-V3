import fetch from 'node-fetch'
import moment from 'moment-timezone'
let handler = async(m, { conn, usedPrefix, text, args, command }) => {
	let d = new Date(new Date + 3600000)
    let locale = 'id'
    // d.getTimeZoneOffset()
    // Offset -420 is 18.00
    // Offset    0 is  0.00
    // Offset  420 is  7.00
    let weton = ['Pahing', 'Pon', 'Wage', 'Kliwon', 'Legi'][Math.floor(d / 84600000) % 5]
    let week = d.toLocaleDateString(locale, { weekday: 'long' })
    let date = d.toLocaleDateString(locale, {
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    })
    let wibh = moment.tz('Asia/Jakarta').format('HH')
    let wibm = moment.tz('Asia/Jakarta').format('mm')
    let wibs = moment.tz('Asia/Jakarta').format('ss')
    let wktuwib = `${wibh} H ${wibm} M ${wibs} S`
if (global.db.data.chats[m.chat].nsfw == false && m.isGroup) return conn.sendButton(m.chat, '❗ ᴏᴘᴛɪᴏɴs ɴsғᴡ ᴅɪᴄʜᴀᴛ ɪɴɪ ʙᴇʟᴜᴍ ᴅɪɴʏᴀʟᴀᴋᴀɴ ᴏʟᴇʜ ᴀᴅᴍɪɴ ɢʀᴏᴜᴘ',`⻝ 𝗗𝗮𝘁𝗲: ${week} ${date}\n⻝ 𝗧𝗶𝗺𝗲: ${wktuwib}`, null, [['ᴇɴᴀʙʟᴇ', '.on nsfw']], m)
if (command == 'caribokep') {
if (!text) throw `Contoh penggunaan ${usedPrefix}${command} japan`
  let json = await fetch(`https://api.lolhuman.xyz/api/pornhubsearch?apikey=RyHar&query=${text}`)
  let jsons = await json.json()
        let caption = `*⎔┉━「 ${command} 」━┉⎔*`
        for (let x of jsons.result) {
        caption += `
Judul *${x.title}*
Info: ${x.info}
Link: ${x.link}
`}
        return m.reply(caption)
    }
    if (command == 'caribokep1') {
if (!text) throw `Contoh penggunaan ${usedPrefix}${command} japan`
  let json = await fetch(`https://api.lolhuman.xyz/api/pornhubsearch?apikey=RyHar&query=${text}`)
  let jsons = await json.json()
        let caption = `*⎔┉━「 ${command} 」━┉⎔*`
        for (let x of jsons.result) {
        caption += `
Judul *${x.title}*
views: ${x.views}
author: ${x.author}
link: ${x.link}
`}
        return m.reply(caption)
    }

}
handler.command = handler.help = ['caribokep', 'caribokep1']
handler.tags = ['nsfw', 'premium']
handler.premium = true

export default handler
