import fetch from 'node-fetch'
let handler = async(m, { conn, text }) => {
  let res = await (await fetch('https://api.lolhuman.xyz/api/cerpen?apikey=RyHar'))
  if (!res.ok) throw await res.text()
  let json = await res.json()
  if(!json.result) throw json
  let { title, creator, cerpen } = await json.result
  conn.sendButton(m.chat, `*Judul:* ${title}`, `*Creator:* ${creator}\n*Cerita:*\n${cerpen}`, [['C E R P E N', '.cerpen']], m)
}
handler.help = ['cerpen']
handler.tags = ['internet']
handler.command = /^(cerpen)$/i
handler.limit = true
export default handler