import fetch from 'node-fetch'
let handler = async (m, { text, command, usedPrefix }) => {
	if (!text) return conn.reply(m.chat, 'Harap Masukan Nama Filmnya', m)
	 let res = await fetch(`https://api.lolhuman.xyz/api/lk21?apikey=${global.lolkey}&query=${text}`)
	 let jsons = await res.json()
	 let x = jsons.result
let hasil = `*${htki} FILM-SEARCH ${htka}*\n\n📫 Film Dari : ${x.title}
📮 Genre: : ${x.genre}
📮 Views: : ${x.views}
📮 Duration: : ${x.duration}
📮 Tahun: : ${x.tahun}
📮 Location: : ${x.location}
📮 Rilis: : ${x.date_release}
📮 Bahasa: : ${x.language}
⭐ Rating : ${x.rating}

🎥Link Streaming 1: ${x.link_dl}

🎥Link Streaming 2: ${x.link}

📖Sinopsis : ${x.desc}`
    await conn.sendButton(m.chat, hasil, wm, null, [['Ok 🤙', 'ok']], m)
    }
handler.help = ['lk21 <judul>', 'film <judul>']
handler.tags = ['internet']
handler.command = /^lk21|film$/i
export default handler