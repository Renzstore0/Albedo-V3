import fetch from 'node-fetch'

//Plugin By Xynoz!!
let handler = async (m, { conn, usedPrefix }) => {
	let url = 'https://telegra.ph/file/e8f1b8c5abcf74adf8efe.jpg'
	let donasi = `
╭─「 • *ᴘᴜʟꜱᴀ* • 」
│ • *ᴛʜʀᴇᴇ* 0895341999786
╰─────

╭─「 • *ᴇ-ᴡᴀʟʟᴇᴛ* • 」
│ • *ᴅᴀɴᴀ* ꜱɪʟᴀʜᴋᴀɴ ꜱᴄᴀɴ Qʀɪꜱ ᴅɪᴀᴛᴀꜱ
│ • *ɢᴏᴘᴀʏ* ꜱɪʟᴀʜᴋᴀɴ ꜱᴄᴀɴ Qʀɪꜱ ᴅɪᴀᴛᴀꜱ
│ • *ᴏᴠᴏ* ꜱɪʟᴀʜᴋᴀɴ ꜱᴄᴀɴ Qʀɪꜱ ᴅɪᴀᴛᴀꜱ
│ • *ꜱᴀᴡᴇʀɪᴀ* https://saweria.co/stirerenz
╰─────

_◛˖ ᴛᴇʀɪᴍᴀᴋᴀꜱɪʜ ᴜɴᴛᴜᴋ ʏᴀɴɢ ꜱᴜᴅᴀʜ ʙᴇʀᴅᴏɴᴀꜱɪ_\n_ᴊɪᴋᴀ ɪɴɢɪɴ ɴᴀᴍᴀɴʏᴀ ᴅɪᴍᴀꜱᴜᴋᴀɴ ᴅɪ ʟʙ ᴅᴏɴᴀꜱɪ ꜱɪʟᴀʜᴋᴀɴ ᴄʜᴀᴛ ᴏᴡɴᴇʀ..._`
	conn.sendButton(m.chat, `*${htki} 𝙳𝙾𝙽𝙰𝚃𝙸𝙾𝙽 ${htka}*`, donasi, await(await fetch(url)).buffer(), [['ᴏᴡɴᴇʀ',`/owner`]],m)
}
handler.command = /^(donasi|dns)$/i
handler.tags = ['info']
handler.help = ['donasi']
handler.premium = false
handler.limit = false

export default handler

// 📮 Made In Xynoz 
// Subscribe YouTube Xynoz!
// Tq To Jangan Di Hpus!!