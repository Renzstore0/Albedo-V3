import fetch from 'node-fetch'

let handler = async (m, { conn, command }) => {
	let url = 'https://web-production-2f5c.up.railway.app/api/wallpaper/naruto?apikey=galang'
	conn.sendButton(m.chat, '(≧ω≦)', wm, await(await fetch(url)).buffer(), [['🔁Next🔁',`.${command}`]],m)
}
handler.command = /^naruto$/i
handler.tags = ['anime']
handler.help = ['naruto']
handler.premium = false
handler.limit = true

export default handler