import fetch from 'node-fetch'
let handler = async (m, { conn, args }) => {
let response = args.join(' ').split('|')
  if (!args[0]) throw 'Masukkan Parameter'
  m.reply('Proses...')
  let res = `https://api.lolhuman.xyz/api/textprome/jokerlogo?apikey=RyHar&text=${response[0]}`
  conn.sendFile(m.chat, res, 'joker.jpg', `Sudah Jadi`, m, false)
}
handler.help = ['logojoker'].map(v => v + ' <text>')
handler.tags = ['nulis']
handler.command = /^(logojoker)$/i

handler.premium = true

export default handler
