function handler(m, { conn, text, usedPrefix, command }) {
if (!text) throw `Contoh:
${usedPrefix + command} halo dek`

let vn = `https://api.lolhuman.xyz/api/gtts/id?apikey=RyHar&text=${text}`
conn.sendFile(m.chat, vn, 'elainabot.mp3', null, m, true, {
type: 'audioMessage',
ptt: true })
    
}
handler.command = ['vn']
handler.help = ['vn <kata>']
handler.tags = ['fun']

handler.limit = true
export default handler

