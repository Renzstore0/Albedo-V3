import fetch from 'node-fetch'
let handler = async(m, { conn, usedPrefix, command, text }) => {
	if (!text) throw `Example ${usedPrefix + command} mantra hujan`
	try {
	let url = await fetch(`https://api.lolhuman.xyz/api/spotifysearch?apikey=RyHar&query=${text}`)
	let res = await url.json()
	let ress = res.result[0]
	let res1 = await fetch(`https://api.lolhuman.xyz/api/spotify?apikey=RyHar&url=${ress.external_urls.spotify}`)
	let ayank = await res1.json()
	let teks = `*乂 SPOTIFY*
	
❃ *Title:* ${ress.title}
❃ *Artist:* ${ress.artists}
❃ *Id:* ${ress.id}
`
conn.sendButton(m.chat, teks, wm, `${ayank.result.thumbnail}`, [['Mp3!', `.spotifyaudio ${ress.external_urls.spotify}`]], m)
} catch (e) {
	throw `Title ${text} Not Found`
	}
}
handler.help = ['spotify <query>']
handler.tags = ['sound']
handler.command = /^sportify|spotify$/i
export default handler

