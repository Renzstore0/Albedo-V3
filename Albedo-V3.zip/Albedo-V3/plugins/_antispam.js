import moment from 'moment-timezone'
export async function all(m) {
	let d = new Date(new Date + 3600000)
    let locale = 'id'
    // d.getTimeZoneOffset()
    // Offset -420 is 18.00
    // Offset    0 is  0.00
    // Offset  420 is  7.00
    let weton = ['Pahing', 'Pon', 'Wage', 'Kliwon', 'Legi'][Math.floor(d / 84600000) % 5]
    let week = d.toLocaleDateString(locale, { weekday: 'long' })
    let date = d.toLocaleDateString(locale, {
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    })
    let wibh = moment.tz('Asia/Jakarta').format('HH')
    let wibm = moment.tz('Asia/Jakarta').format('mm')
    let wibs = moment.tz('Asia/Jakarta').format('ss')
    let wktuwib = `${wibh} H ${wibm} M ${wibs} S`
    let name = conn.getName(m.sender)
    
    if (!m.message)
        return
    this.spam = this.spam ? this.spam : {}
    if (m.sender in this.spam) {
        this.spam[m.sender].count++
        if (m.messageTimestamp.toNumber() - this.spam[m.sender].lastspam > 10) {
            if (this.spam[m.sender].count > 10) {
                global.db.data.users[m.sender].banned = true
                global.db.data.users[m.sender].bannedTime += 1
                //Pembatas
                
                conn.reply(global.nomorown + '@s.whatsapp.net', `*Nama:* ${name}
*Nomor:* @${m.sender.split`@`[0]}
*Total Spam:* ${global.db.data.users[m.sender].bannedTime}

*Jam:* ${wktuwib}
*Tanggal:* ${week} ${date}

Telah *DiBanned* Dikarenakan Spam!!`, null, {
        contextInfo: {
            mentions: [m.sender]
        }
    })
                //Pembatas
                m.reply(`Kamu Telah *DIBANNED* Karena Spam!!\n\nSilahkan Menghubungi Owner Agar Di Unban\nwa.me/${global.nomorown}?text=[💬]Bang+Tolong+Unban+Saya`)
                
            }
            this.spam[m.sender].count = 0
            this.spam[m.sender].lastspam = m.messageTimestamp.toNumber()
        }
    }
    else
        this.spam[m.sender] = {
            jid: m.sender,
            count: 0,
            lastspam: 0
        }
}