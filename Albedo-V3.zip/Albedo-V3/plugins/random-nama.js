/**
* cuma mau bilang terimakasih ama https://github.com/uhdahlah
**/


import axios from "axios"
let handler = async(m, { conn, text }) => {

    await m.reply('Searching...')
	axios.get(`https://api.lolhuman.xyz/api/random/nama?apikey=RyHar`).then ((res) => {
	 	let hasil = `*Nama:* ${res.data.result}`

    conn.sendButton(m.chat, hasil ,wm , null, [['N E X T','.randomnama']], m)
	})
}
handler.help = ['randomnama']
handler.tags = ['fun']
handler.command = /^(randomnama)$/i
handler.owner = false
handler.exp = 0
handler.limit = true
// https://github.com/uhdahlah
export default handler
