import fetch from 'node-fetch'
let handler = async(m, { conn, text, args, usedPrefix }) => {
  let response = args.join(' ').split('|')
  if (!args[0]) throw `Masukan Nama\nContoh: ${usedPrefix}kecocokan Kucing|Anjing`
  let res = await (await fetch(`https://api.lolhuman.xyz/api/jodoh/${response[0]}/${response[1]}?apikey=RyHar`))
  if (!res.ok) throw await res.text()
  let json = await res.json()
  if(!json.result) throw json
  let { image, positif, negatif, deskripsi } = await json.result
  conn.sendButton(m.chat, `*Nama:* ${response[0]} Dan ${response[1]}\n\n*Positif:* ${positif}\n\n*Negatif:* ${negatif}\n\n*Deskripsi:* ${deskripsi}`, wm, await(await fetch(image)).buffer(), [['D O N A S I', `${usedPrefix}donasi`]], m)
}
handler.help = ['kecocokan <nama|nama>']
handler.tags = ['fun']
handler.command = /^kecocokan$/i
handler.limit = true
export default handler