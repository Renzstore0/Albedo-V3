import fetch from 'node-fetch'
let handler = async (m, { conn, args }) => {
   let response = args.join(' ').split('|')
  if (!args[0]) throw 'ᴍᴀꜱᴜᴋᴋᴀɴ ᴛᴇxᴛ'
  m.reply('ᴘʀᴏꜱᴇꜱ...')
  
  let res = `https://api.lolhuman.xyz/api/textprome/newyearcard?apikey=RyHar&text=${response[0]}`
  conn.sendFile(m.chat, res, 'xynz.jpg', `ꜱᴜᴅᴀʜ ᴊᴀᴅɪ`, m, false)
}
handler.help = ['newyear'].map(v => v + ' <text>')
handler.tags = ['nulis']
handler.command = /^(newyear)$/i

handler.limit = true

export default handler