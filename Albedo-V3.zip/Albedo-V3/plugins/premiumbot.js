let handler = async (m, { conn, text, usedPrefix }) => {
    let sewa = `  
❏ Harga
• 15 Hari 5k
• 30 Hari 10k
• 45 Hari 15k
• 60 Hari 20k
• Permanen 30k

❏ Fitur
• Unlimited Limit
• Nsfw
• Terorbug
• Dan Lain Lain

Minat? Silahkan Chat Owner...
`
        await conn.sendButton(m.chat, `*––––––『 Premium 』––––––*`, sewa, 'https://telegra.ph/file/0129a2d94b528d71331f5.jpg', [['SewaBOT', '.sewa'], ['Payment', '.pay']], m)
}
handler.help = ['premium']
handler.tags = ['info', 'main']

handler.command = /^(premium|prem)$/i

export default handler
