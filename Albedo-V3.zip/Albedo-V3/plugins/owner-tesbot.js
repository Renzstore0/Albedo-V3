import fetch from 'node-fetch'
let handler = async (m) => {
  m.reply('Bot Aktif Kak')
}
handler.help = ['tesbot']
handler.tags = ['main']
handler.command = /^(tesbot)$/i

export default handler