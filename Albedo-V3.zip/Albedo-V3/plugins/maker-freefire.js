import fetch from 'node-fetch'
let handler = async (m, { conn, args }) => {
let response = args.join(' ').split('|')
  if (!args[0]) throw 'Masukkan Parameter'
  m.reply('Proses...')
  let res = `https://api.lolhuman.xyz/api/ephoto1/freefire?apikey=${global.lolkey}&text=${response[0]}`
  conn.sendFile(m.chat, res, 'joker.jpg', `Sudah Jadi`, m, false)
}
handler.help = ['freefire'].map(v => v + ' <text>')
handler.tags = ['nulis']
handler.command = /^(freefire)$/i

handler.premium = true

export default handler
