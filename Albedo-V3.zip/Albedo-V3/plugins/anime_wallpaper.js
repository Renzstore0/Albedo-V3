import fetch from 'node-fetch'

let handler = async (m, { conn, command }) => {
	let url = `https://api.lolhuman.xyz/api/random/wallnime?apikey=${global.lolkey}`
	conn.sendButton(m.chat, 'Nih Wallpapernya (≧ω≦)', wm, await(await fetch(url)).buffer(), [['🔁Next🔁',`.${command}`]],m)
}
handler.tags = ['anime']
handler.command = /^(wallpaperanime|animewallpaper)$/i
handler.help = ['animewallpaper']
handler.premium = false
handler.limit = true

export default handler