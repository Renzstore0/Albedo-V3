import fetch from 'node-fetch'

let handler = async (m, { conn, command }) => {
	let url = 'https://web-production-2f5c.up.railway.app/api/wallpaper/madara?apikey=galang'
	conn.sendButton(m.chat, '(≧ω≦)', wm, await(await fetch(url)).buffer(), [['🔁Next🔁',`.${command}`]],m)
}
handler.command = /^madara$/i
handler.tags = ['anime']
handler.help = ['madara']
handler.premium = false
handler.limit = true

export default handler