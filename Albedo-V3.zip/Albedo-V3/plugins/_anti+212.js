let handler = m => m

handler.before = async function (m) {
   if (m.sender.startsWith('212' || '212')) {
   	m.reply('see u next time')
await conn.updateBlockStatus(m.sender, "block")
   }
   
   if (m.sender.startsWith('92' || '92')) {
   	m.reply('see u next time')
await conn.updateBlockStatus(m.sender, "block")
   } 
    
    if (m.sender.startsWith('265' || '265')) {
   	m.reply('see u next time')
await conn.updateBlockStatus(m.sender, "block")
   } 
    
    if (m.sender.startsWith('93' || '93')) {
   	m.reply('see u next time')
await conn.updateBlockStatus(m.sender, "block")
   } 
   
   if (m.sender.startsWith('55' || '55')) {
   	m.reply('see u next time')
await conn.updateBlockStatus(m.sender, "block")
   } 
    }

export default handler
