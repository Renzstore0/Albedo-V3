import util from 'util'
import path from 'path'
import fetch from 'node-fetch'
let handler = async (m, { conn }) => {
let k = Math.floor(Math.random() * 70);
    m.reply('ᴍᴏʜᴏɴ ᴛᴜɴɢɢᴜ...')
let albedo = 'https://telegra.ph/file/2d2efaa83ec0dc610cb68.jpg'
let vn = `https://hansxd.nasihosting.com/sound/sound${k}.mp3`
conn.sendFile(m.chat, vn, 'Fangz.ganz', null, m, true, {
type: 'audioMessage', 
ptt: false, seconds: 0,contextInfo: {
         externalAdReply: { showAdAttribution: true,
    mediaUrl: 'www.instagram.com/calme.renz16',
    mediaType: 1, 
    description: 'www.instagram.com/calme.renz16',
    title: "▶︎ ━━━━━━━•────────────            ⇆ㅤ◁ㅤ ❚❚ㅤ ▷ㅤ↻",
    renderLargerThumbnail: true,
    thumbnail: await (await fetch(albedo)).buffer(),
    thumbnailUrl: sgc,
    sourceUrl: sig
}
     }
    })
}
handler.help = ['randomsound']
handler.tags = ['sound']
handler.command = /^(randomsound)$/i
handler.fail = null
handler.exp = 100
export default handler