import fetch from 'node-fetch'
let handler = async (m, { text, usedPrefix, command }) => {
 
  if (!text) throw `uhm.. cari apa?\n\ncontoh:\n${usedPrefix + command} mabar`
    let imgr = flaaa.getRandom()
    let f = await fetch(`https://api.lolhuman.xyz/api/groupwhatsapp2?apikey=RyHar&query=${text}`)
let xx = await f.json()
let v = xx.result
let teks = v.map(v => {
return `
🪀 *Nama Group* : ${v.title}
📎 *Link Group :* ${v.link}
      `.trim()
  }).filter(v => v).join('\n\n▣═━–〈 *SEARCH* 〉–━═▣\n\n')
  //m.reply(teks)
  await conn.sendButton(m.chat, teks, wm, `${imgr + 'Group WhatsApp'}`, [
                ['CARI 🔎', `${usedPrefix + command} ${text}`]
            ], m)
            
}
handler.help = ['gcwa'].map(v => v + ' <apa>')
handler.tags = ['tools']
handler.command = ['gcwa']

export default handler