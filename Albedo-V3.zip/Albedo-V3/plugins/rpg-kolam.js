let { MessageType } = (await import('@adiwajshing/baileys')).default
let handler = async (m, { conn }) => {
if (global.db.data.chats[m.chat].rpg == false && m.isGroup) return conn.sendButton(m.chat, '❗ ᴏᴘᴛɪᴏɴs ʀᴘɢ ɢᴀᴍᴇ ᴅɪᴄʜᴀᴛ ɪɴɪ ʙᴇʟᴜᴍ ᴅɪɴʏᴀʟᴀᴋᴀɴ ᴏʟᴇʜ ᴀᴅᴍɪɴ ɢʀᴏᴜᴘ', wm, null, [['ᴇɴᴀʙʟᴇ', '.on rpg']], m)
let name = global.db.data.users[m.sender].name
let level = global.db.data.users[m.sender].level
let exp = global.db.data.users[m.sender].exp
let kepiting = global.db.data.users[m.sender].kepiting
let lobster = global.db.data.users[m.sender].lobster
let udang = global.db.data.users[m.sender].udang
let cumi = global.db.data.users[m.sender].cumi
let gurita = global.db.data.users[m.sender].gurita
let buntal = global.db.data.users[m.sender].buntal
let dory = global.db.data.users[m.sender].dory
let orca = global.db.data.users[m.sender].orca
let lumba = global.db.data.users[m.sender].lumba
let paus = global.db.data.users[m.sender].paus
let hiu = global.db.data.users[m.sender].hiu

let past = `
╭━━━━「 *BIO* 」   
┊ *💌 Name :* ${name}
┊ *📊 Level :* ${level}
┊ *✨ Exp :* ${exp}
╰═┅═━––––––─ׄ✧

╭━━━━「 *ISI* 」
┊🦀 Kepiting: ${kepiting}
┊🦞 Lobster: ${lobster}
┊🦐 Udang: ${udang}
┊🦑 Cumi: ${cumi}
┊🐙 Gurita: ${gurita}
┊🐡 Buntal: ${buntal}
┊🐠 Dory: ${dory}
┊🐳 Orca: ${orca}
┊🐬 Lumba: ${lumba}
┊🐋 Paus: ${paus}
┊🦈 Hiu: ${hiu}
╰═┅═━––––––─ׄ✧
🎏 Total Isi: *${kepiting + lobster + udang + cumi + gurita + buntal + dory + orca + lumba + paus + hiu}* Jenis`
  conn.sendButton(m.chat, `*––––––「 KOLAM 🏝️ 」––––––*`, past, [['Pasar', '#pasar']], m)
  }
  handler.help = ['kolam']
  handler.tags = ['rpg']
  handler.command = /^(kotak(ikan)?|kolam(ikan)?)$/i
export default handler 
handler.register = true
let wm = global.wm

const more = String.fromCharCode(8206)
const readMore = more.repeat(4001)
