import fetch from 'node-fetch'

let handler = async (m, { conn, command }) => {
	let url = 'https://web-production-2f5c.up.railway.app/api/wallpaper/boruto?apikey=galang'
	conn.sendButton(m.chat, '(≧ω≦)', wm, await(await fetch(url)).buffer(), [['🔁Next🔁',`.${command}`]],m)
}
handler.command = /^boruto$/i
handler.tags = ['anime']
handler.help = ['boruto']
handler.premium = false
handler.limit = true

export default handler