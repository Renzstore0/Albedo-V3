import fs from 'fs'
 let handler = m => m 
  
 handler.all = async function (m, { isBlocked, usedPrefix }) { 
     if (isBlocked) return 
     let sewaelaina = {
            key:
            { fromMe: false,
            participant: `0@s.whatsapp.net`, ...(m.chat  ? 
            { remoteJid: "status@broadcast" } : {}) },
            message: { "liveLocationMessage": { "caption":"ʟɪꜱᴛ ʜᴀʀɢᴀ ꜱᴇᴡᴀ","h": `${wm}`, 'jpegThumbnail': fs.readFileSync('./thumbnail.jpg')}}
           }
     // ketika ada yang invite/kirim link grup di chat pribadi 
     if ((m.mtype === 'groupInviteMessage' || m.text.startsWith('Undangan untuk bergabung') || m.text.startsWith('Invitation to join') || m.text.startsWith('Buka tautan ini')) && !m.isBaileys && !m.isGroup) { 
     let teks = `
*${htki} 𝚂𝚎𝚠𝚊𝙱𝚘𝚝 ${htka}*
  
• 15 Hᴀʀɪ 3,5ᴋ / Gʀᴏᴜᴘ
• 30 Hᴀʀɪ 7ᴋ / Gʀᴏᴜᴘ
• 45 Hᴀʀɪ 10,5ᴋ / Gʀᴏᴜᴘ
• 60 Hᴀʀɪ 14ᴋ / Gʀᴏᴜᴘ
• Pᴇʀᴍᴀɴᴇɴ 30ᴋ / Gʀᴏᴜᴘ 

*𝙵𝚒𝚝𝚞𝚛 𝙱𝚘𝚝:*

• ᴀɴᴛɪ ʟɪɴᴋ
• ᴡᴇʟᴄᴏᴍᴇ
• ᴋɪᴄᴋ
• ʀᴘɢ ɢᴀᴍᴇꜱ
• ᴅᴏᴡɴʟᴏᴀᴅᴇʀ
• ʙᴜɢ/ᴠɪʀᴛᴇx
• ɴꜱꜰᴡ

*𝚃𝚘𝚝𝚊𝚕 𝙵𝚒𝚝𝚞𝚛 𝙱𝚘𝚝 𝟻𝟷𝟻+*

*𝙿𝚊𝚢𝚖𝚎𝚗𝚝:*
• ɢᴏᴘᴀʏ
• ᴘᴜʟꜱᴀ
• ᴅᴀɴᴀ
• Qʀɪꜱ

ᴊɪᴋᴀ ᴍɪɴᴀᴛ, ꜱɪʟᴀʜᴋᴀɴ ᴄʜᴀᴛ ᴏᴡɴᴇʀ ᴀᴛᴀᴜ
ᴋᴇᴛɪᴋ #ᴘᴀʏ
ᴅᴀɴ ᴋɪʀɪᴍ ʙᴜᴋᴛɪ ᴘᴇᴍʙᴀʏᴀʀᴀɴ ᴋᴇ ᴏᴡɴᴇʀ
`
     this.sendButton(m.chat, renz, teks, 'https://telegra.ph/file/d3887aa2c57c191988561.jpg', [["ᴘʀᴇᴍɪᴜᴍ", "#premium"], ["ᴘᴀʏᴍᴇɴᴛ", "#pay"]], sewaelaina)
     const data = global.owner.filter(([id, isCreator]) => id && isCreator) 
     this.sendKontak(m.chat, global.owner, m, { contextInfo: { externalAdReply :{
    showAdAttribution: true,
     }}
  })
     } 
 } 
  
 export default handler