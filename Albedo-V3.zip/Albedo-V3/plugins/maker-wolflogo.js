import fetch from 'node-fetch'
let handler = async (m, { conn, args }) => {
   let response = args.join(' ').split('|')
  if (!args[0]) throw 'ᴍᴀꜱᴜᴋᴋᴀɴ ᴛᴇxᴛ'
  m.reply('ᴘʀᴏꜱᴇꜱ...')
  
  let res = `https://api.lolhuman.xyz/api/textprome2/wolflogo?apikey=RyHar&text1=${response[0]}&text2=${response[1]}`
  conn.sendFile(m.chat, res, 'xynz.jpg', `ꜱᴜᴅᴀʜ ᴊᴀᴅɪ`, m, false)
}
handler.help = ['logowolf'].map(v => v + ' <text1|text2>')
handler.tags = ['nulis']
handler.command = /^(logowolf)$/i

handler.limit = true

export default handler