import fetch from 'node-fetch'
let handler = async (m, { conn, args }) => {
let response = args.join(' ').split('|')
  if (!args[0]) throw 'Masukkan Parameter'
  m.reply('Proses...')
  let res = `https://api.lolhuman.xyz/api/ephoto1/anonymhacker?apikey=RyHar&text=${response[0]}`
  conn.sendFile(m.chat, res, 'gaming.jpg', `Sudah Jadi`, m, false)
}
handler.help = ['logohacker'].map(v => v + ' <text>')
handler.tags = ['nulis']
handler.command = /^(logohacker)$/i

handler.limit = true

export default handler
