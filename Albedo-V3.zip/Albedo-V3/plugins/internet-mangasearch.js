import xfar from 'xfarr-api'
import fs from 'fs'
import fetch from 'node-fetch'
let handler = async(m, { conn, args }) => {
  let response = args.join(' ').split('|')
  let res = await (await fetch(`https://api.lolhuman.xyz/api/manga?apikey=RyHar&query=${response[0]}`))
  if (!res.ok) throw await res.text()
  let json = await res.json()
  if(!json.result) throw json
  let { romaji } = await json.result.title
  let { large } = await json.result.coverImage
  let { description } = await json.result
  conn.sendButton(m.chat, `*Judul:* ${romaji}\n*Volume:* ${json.result.volumes}\n*Status:* ${json.result.status}\n*Genre:* ${json.result.genres}\n\n*StartDate:* \nYear: ${json.result.startDate.year}\nMonth: ${json.result.startDate.month}\nDay: ${json.result.startDate.day}\n\n*EndDate:* \nYear: ${json.result.endDate.year}\nMonth: ${json.result.endDate.month}\nDay: ${json.result.endDate.day}\n\n*Deskripsion:* ${description}`,wm, await(await fetch(large)).buffer(), [['ᴅᴏɴᴀᴛɪᴏɴ', '.donasi']], m)
}
handler.help = ['mangasearch']
handler.tags = ['internet']
handler.command = /^mangasearch$/i
handler.limit = true
export default handler