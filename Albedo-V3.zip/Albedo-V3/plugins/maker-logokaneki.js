import fetch from 'node-fetch'
let handler = async (m, { conn, text }) => {
  if (!text) throw 'Masukkan Parameter'
  m.reply('Proses...')
  let res = `https://xznsenpai.xyz/docs/gfx1?name=${text}`
  conn.sendFile(m.chat, res, 'kaneki.jpg', `Sudah Jadi`, m, false)
}
handler.help = ['logokaneki'].map(v => v + ' <text>')
handler.tags = ['nulis']
handler.command = /^(logokaneki)$/i

handler.limit = true

export default handler