import fs from 'fs'
import fetch from 'node-fetch'
import moment from 'moment-timezone'
let handler = async (m, { conn, usedPrefix, isAdmin, isOwner, text }) => {
    let wibh = moment.tz('Asia/Jakarta').format('HH')
    let wibm = moment.tz('Asia/Jakarta').format('mm')
    let wibs = moment.tz('Asia/Jakarta').format('ss')
    let wktuwib = `${wibh} H ${wibm} M ${wibs} S`
    let imgr = 'https://telegra.ph/file/5ef4408a9bcceaccfc125.jpg'
	if (m.isGroup) {
		switch (text) {
			case 'off': {
				global.db.data.chats[m.chat].isBanned = true
				conn.reply(m.chat, 'Yaudah, Aku Off Dulu Ya Kak🥲', m)
}
				break
			case 'on': {
				global.db.data.chats[m.chat].isBanned = false
				conn.reply(m.chat, 'Yeyy Dihidupin🥰, Apanih Yang Bisa Aku Bantu?😁', m)
}
				break
			default: {
				conn.sendButton(m.chat, '_Silahkan pilih opsi_', 'Opsi ini untuk mengaktifkan/nonaktifkan bot untuk group', imgr, [['ON', '.bot on'], ['OFF', '.bot off']], m, { contextInfo:
 { externalAdReply: 
{title: `⻝ 𝗧𝗶𝗺𝗲: ${wktuwib}`, 
body: 'Bot Whatsapp', 
sourceUrl: sig, 
thumbnail: await(await fetch('https://telegra.ph/file/cb575edf564b44dc8dcad.jpg')).buffer()
}}})
			}
		}
	} 
}
handler.help = ['bot [on/off]']
handler.tags = ['group']
handler.command = /^(bot)$/i
handler.group = true
handler.admin = true

export default handler