import fetch from 'node-fetch'
let handler = async (m, {command, conn}) => {
let res = `https://api.lolhuman.xyz/api/meme/memeindo?apikey=${global.lolkey}`
conn.sendButton(m.chat, `*${command}*`.trim(), author, await(await fetch(res)).buffer(), [['🔄 NEXT 🔄', `/${command}`]], m)
}
handler.help = ['meme']
handler.tags = ['random']
handler.command = /^(meme)$/i
export default handler
