/**
* cuma mau bilang terimakasih ama https://github.com/uhdahlah
**/


import axios from "axios"
import moment from 'moment-timezone'
let handler = async(m, { conn, text }) => {
	let d = new Date(new Date + 3600000)
    let locale = 'id'
    // d.getTimeZoneOffset()
    // Offset -420 is 18.00
    // Offset    0 is  0.00
    // Offset  420 is  7.00
    let weton = ['Pahing', 'Pon', 'Wage', 'Kliwon', 'Legi'][Math.floor(d / 84600000) % 5]
    let week = d.toLocaleDateString(locale, { weekday: 'long' })
    let date = d.toLocaleDateString(locale, {
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    })
    let wibh = moment.tz('Asia/Jakarta').format('HH')
    let wibm = moment.tz('Asia/Jakarta').format('mm')
    let wibs = moment.tz('Asia/Jakarta').format('ss')
    let wktuwib = `${wibh} H ${wibm} M ${wibs} S`
	
    if (global.db.data.chats[m.chat].nsfw == false && m.isGroup) return conn.sendButton(m.chat, '❗ ᴏᴘᴛɪᴏɴs ɴsғᴡ ᴅɪᴄʜᴀᴛ ɪɴɪ ʙᴇʟᴜᴍ ᴅɪɴʏᴀʟᴀᴋᴀɴ ᴏʟᴇʜ ᴀᴅᴍɪɴ ɢʀᴏᴜᴘ',`⻝ 𝗗𝗮𝘁𝗲: ${week} ${date}\n⻝ 𝗧𝗶𝗺𝗲: ${wktuwib}`, null, [['ᴇɴᴀʙʟᴇ', '.on nsfw']], m)
    if (!text) return conn.reply(m.chat, 'Input Code', m)

    await m.reply('Searching...')
	axios.get(`https://api.lolhuman.xyz/api/nhentaipdf/${text}?apikey=RyHar`).then ((res) => {
	 	let hasil = `Download Sendiri Jangan Manja\n${res.data.result}`

    conn.reply(m.chat, hasil, m)
	})
}
handler.help = ['nhentai'].map(v => v + ' <kode>')
handler.tags = ['nsfw', 'premium']
handler.command = /^(nhentai ?)$/i
handler.premium = true
// https://github.com/uhdahlah
export default handler
