import fetch from 'node-fetch'
let handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) throw `Example ${usedPrefix + command} https://www.instagram.com/reel/CmS-59tA_nF/?igshid=MDM4ZDc5MmU=`
  let elaina = await fetch(`https://api.lolhuman.xyz/api/instagram?apikey=RyHar&url=${text}`)
  let image = await elaina.json()
  let a = image.result
  for (let data of a) { 
         await conn.sendFile(m.chat, data, 'ryhar.jr', '', m).catch(console.error) 
         await delay(1500) 
     } 
 }
 handler.help = ['instagram'].map(v => v + ' <url>')
handler.tags = ['downloader']
handler.command = /^ig|instagram|igmp4|igdownload|instagrammp4$/i
handler.limit = true

export default handler
const delay = time => new Promise(res => setTimeout(res, time))