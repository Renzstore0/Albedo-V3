import fetch from 'node-fetch'
let handler = async (m, { conn, args, usedPrefix, command  }) => {
   let response = args.join(' ').split('|')
  if (!response[0]|!response[1]) throw `*ᴄᴏᴍᴍᴀɴᴅ ʏᴀɴɢ ᴀɴᴅᴀ ᴍᴀꜱᴜᴋᴀɴ ꜱᴀʟᴀʜ*\nᴄᴏɴᴛᴏʜ: ${usedPrefix + command} text1|text2`
  m.reply('ᴘʀᴏꜱᴇꜱ...')
  
  let res = `https://api.lolhuman.xyz/api/textprome2/avenger?apikey=RyHar&text1=${response[0]}&text2=${response[1]}`
  conn.sendFile(m.chat, res, 'xynz.jpg', `ꜱᴜᴅᴀʜ ᴊᴀᴅɪ`, m, false)
}
handler.help = ['avenger'].map(v => v + ' <text1|text2>')
handler.tags = ['nulis']
handler.command = /^(avenger)$/i

handler.limit = true

export default handler