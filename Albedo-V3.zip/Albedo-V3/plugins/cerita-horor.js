import xfar from 'xfarr-api'
import fs from 'fs'
import fetch from 'node-fetch'
let handler = async(m, { conn, text, args }) => {
  let i = await xfar.Film(args[0])
  let res = await (await fetch('https://api.lolhuman.xyz/api/ceritahoror?apikey=RyHar'))
  if (!res.ok) throw await res.text()
  let json = await res.json()
  if(!json.result) throw json
  let { title, desc, story, thumbnail } = await json.result
  conn.sendButton(m.chat, `*Judul:* ${title}`, `*Descripsion:*  ${desc}\n\n*Cerita:*\n${story}`, await(await fetch(thumbnail)).buffer(), [['CERITA HORROR', '.ceritahoror']], m)
}
handler.help = ['ceritahoror']
handler.tags = ['internet']
handler.command = /^ceritahorror|ceritahoror$/i
handler.limit = true
export default handler