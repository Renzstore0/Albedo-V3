import fetch from 'node-fetch'
let handler = m => m

handler.before = async (m, text ) => {
    let chat = global.db.data.chats[m.chat]
    if (chat.simi && !chat.isBanned ) {
        if (/^.*false|disnable|(turn)?off|0/i.test(m.text)) return
        if (!m.text) return
        let res = await fetch(`https://api.lolhuman.xyz/api/simi?apikey=RyHar&text=${text}&badword=true`)
        if (!res.ok) throw eror
        let json = await res.json()
        if (json.result == 'error') return m.reply('lu ngetik apaaan sih')
        await m.reply(`${json.result}`)
        return !0
    }
    return true
}
export default handler