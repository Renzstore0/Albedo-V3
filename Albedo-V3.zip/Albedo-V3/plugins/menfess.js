let handler = async(m, { conn, usedPrefix, command, text }) => {
    const desc = `*乂 M E N F E S S - C H A T*\n\n*Cara penggunaan :*\n\n${usedPrefix + command} nomor|nama pengirim|pesan\n\n*Note:* nama pengirim boleh nama samaran atau anonymous.\n\n*Contoh:* ${usedPrefix + command} ${m.sender.split`@`[0]}|Rahasia|Halo.
 `.trim()
    let [text1, text2, text3] = text.split('|');
    if(!text) throw desc
    if(!text1.startsWith('628')) throw "*⚠️ Can only be filled with numbers Indonesian people!, for example: 628xxx*"
    if(!text2) throw "*⚠️ Please enter your name!*"
    if(!text3) throw "*⚠️ Please fill in the message!*"
    
    let teks = `Hai kamu menerima pesan Rahasia nih
    
Dari: *${text2}*
Isi Pesan: ${text3}
` 
    conn.sendMessage(text1 + "@s.whatsapp.net",{
	        text: teks,
            footer: wm,
            buttons: [
          { buttonId: `.menfesschat ${m.sender.split("@")[0]}`, buttonText: { displayText: 'Ajak Chat' }, type: 1 }],
             headerType: 1,
            withTag : true 
	        });
    m.reply("*Done mengirim pesan menfess kepada " + text1 + "*")
}

handler.command = /^(menfess)$/i
handler.private = true
handler.tags = ['anonymous']
handler.help = ['menfess']
export default handler


//Wm By Kimimaru
//github: https://github.com/K1mimaru