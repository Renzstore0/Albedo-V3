import fetch from 'node-fetch'
import fs from 'fs'
let handler = async(m, { conn, text, usedPrefix, command }) => {
	if (!text) throw `Example:  ${usedPrefix + command} https://vt.tiktok.com/ZS86d3qG5/`
	try {
	let ayanku = {
            key:
            { fromMe: false,
            participant: `0@s.whatsapp.net`, ...(m.chat  ? 
            { remoteJid: "status@broadcast" } : {}) },
            message: { "liveLocationMessage": { "caption":"Tiktok Downloader","h": `${wm}`, 'jpegThumbnail': fs.readFileSync('./thumbnail.jpg')}}
           }
    m.reply('ꜱᴇᴅᴀɴɢ ᴍᴇɴᴅᴏᴡɴʟᴏᴀᴅ...')
	let x = await (await fetch(`https://api.lolhuman.xyz/api/tiktok?apikey=RyHar&url=${text}`))
	let r = await x.json()
	await conn.sendButton(m.chat, `*${htki} ᴛɪᴋᴛᴏᴋ ${htka}*`, `➔ ɴɪᴄᴋɴᴀᴍᴇ: ${r.result.author.nickname}\n➔ ᴠɪᴇᴡꜱ: ${r.result.statistic.play_count}\n➔ ʟɪᴋᴇꜱ: ${r.result.statistic.like_count}\n➔ ᴅᴇsᴄʀɪᴘᴛɪᴏɴ: ${r.result.title}`, await (await fetch(r.result.link)).buffer(), [['Audio', `.ttmp3 ${text}`]], ayanku, { mentions: [m.sender] })
    } catch (e) {
    	throw 'ᴛᴇʀᴊᴀᴅɪ ᴇʀʀᴏʀ...'
    }
}

handler.help = ['tiktok'].map(v => v + ' <url>')
handler.tags = ['downloader']
handler.command = /^(tiktok|tt)$/i

handler.limit = true

export default handler