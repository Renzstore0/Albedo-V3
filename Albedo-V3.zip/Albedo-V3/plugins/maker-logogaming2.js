import fetch from 'node-fetch'
let handler = async (m, { conn, args }) => {
let response = args.join(' ').split('|')
  if (!args[0]) throw 'Masukkan Parameter'
  m.reply('Proses...')
  let res = `https://api.lolhuman.xyz/api/ephoto1/fpslogo?apikey=RyHar&text=${response[0]}`
  conn.sendFile(m.chat, res, 'logogaming2.jpg', `Sudah Jadi`, m, false)
}
handler.help = ['logogaming2'].map(v => v + ' <text>')
handler.tags = ['nulis']
handler.command = /^(logogaming2)$/i

handler.premium = true

export default handler
