import fetch from 'node-fetch'

let handler = async (m, { conn, command }) => {
	let url = `https://api.lolhuman.xyz/api/random/elf?apikey=${global.lolkey}`
	conn.sendButton(m.chat, 'Waifu nya om (≧ω≦)', wm, await(await fetch(url)).buffer(), [['🔁Next🔁',`.${command}`]],m)
}
handler.command = /^(elf)$/i
handler.tags = ['anime']
handler.help = ['elf']
handler.premium = false
handler.limit = true

export default handler