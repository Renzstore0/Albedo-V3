import fetch from 'node-fetch'
let handler = async(m, { conn, text }) => {
  let res = await (await fetch('https://api.lolhuman.xyz/api/quotes/dilan?apikey=RyHar'))
  if (!res.ok) throw await res.text()
  let json = await res.json()
  if(!json.result) throw json
 
  conn.sendButton(m.chat, `${json.result}`, wm, [['N E X T', '.quotesdilan']], m)
}
handler.help = ['dilan']
handler.tags = ['quotes']
handler.command = /^(quotesdilan|dilan)$/i
handler.limit = true
export default handler