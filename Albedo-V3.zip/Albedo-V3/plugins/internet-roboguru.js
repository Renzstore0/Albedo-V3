import fetch from 'node-fetch'
let handler = async (m, { text, command, usedPrefix }) => {
	if (!text) throw 'Apa Pertanyaannya?'
	let [kelas, pelajaran, pertanyaan] = text.split('|');
	if ((!kelas || !pelajaran || !pertanyaan)) throw `Silahkan Ketik\n${usedPrefix}roboguru kelas|pelajaran|pertanyaan\n\n*Contoh:* ${usedPrefix}roboguru sma|sejarah|Apa Nama Presiden Pertama Indonesia`
    let f = await fetch(`https://api.lolhuman.xyz/api/roboguru?apikey=RyHar&query=${pertanyaan}&grade=${kelas}&subject=${pelajaran}`)
    let xx = await f.json()
    let v = xx.result
    let teks = v.map(v => {
    return `  
*Pertanyaan:*
${v.question}

*Jawaban:*
${v.answer}
      `.trim()
  }).filter(v => v).join('\n\n\n')
  await conn.sendButton(m.chat, teks, wm, null, [
                ['Search!', `${usedPrefix + command}`]
            ], m)
}
handler.help = ['roboguru <teks>']
handler.tags = ['internet']
handler.command = /^roboguru$/i
export default handler