let handler = async(m, { conn, text }) => {
    if (!text) throw 'Mana Linknya?'
	let vn = `${text}`
    conn.sendFile(m.chat, vn, 'ryhar.mp3', null, m, true, {
type: 'audioMessage', 
ptt: true 
})
}
handler.command = /^(jooxaudio)$/i
export default handler
