import fetch from 'node-fetch'
import uploadImage from '../lib/uploadImage.js'
let handler = async (m, { conn, usedPrefix, command }) => {
  let q = m.quoted ? m.quoted : m
  let mime = (q.msg || q).mimetype || ''
  if (!mime) throw 'Fotonya Mana? Reply gambar yg gk ada button aja'
  if (!/image\/(jpe?g|png)/.test(mime)) throw `Tipe ${mime} tidak didukung!`
  let img = await q.download?.()
  let url = await uploadImage(img)
  let f = await fetch(`https://api.lolhuman.xyz/api/genderdetect?apikey=${global.lolkey}&img=${url}`)
  let x = await f.json()
  let caption = `*Gendermu:* ${x.result}`
await conn.sendButton(m.chat, caption, wm, null, [['Search!', `${usedPrefix + command}`]], m)
}
handler.help = ['genderdetect']
handler.tags = ['fun']
handler.command = /^(genderdetect)$/i

handler.limit = true

export default handler