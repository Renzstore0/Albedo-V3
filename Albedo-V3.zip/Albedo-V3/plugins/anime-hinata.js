import fetch from 'node-fetch'

let handler = async (m, { conn, command }) => {
	let url = 'https://hardianto.xyz/api/wallpaper/hinata?apikey=hardianto'
	conn.sendButton(m.chat, 'Waifu nya om (≧ω≦)', wm, await(await fetch(url)).buffer(), [['🔁Next🔁',`.${command}`]],m)
}
handler.command = /^hinata$/i
handler.tags = ['anime']
handler.help = ['hinata']
handler.premium = false
handler.limit = true

export default handler