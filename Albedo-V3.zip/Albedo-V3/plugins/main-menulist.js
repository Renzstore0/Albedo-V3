let { generateWAMessageFromContent } = (await import("@adiwajshing/baileys"))
import { promises } from 'fs'
import { join } from 'path'
import { xpRange } from '../lib/levelling.js'
import moment from 'moment-timezone'
import os from 'os'
import fs from 'fs'
import fetch from 'node-fetch'

const MenuImg = [
'https://telegra.ph/file/6bd70ee42d5f94e0a5c26.jpg',
'https://telegra.ph/file/3b5801edaddbbdf4069df.jpg',
'https://telegra.ph/file/e1e82d17dfb15e5e76cd6.jpg'
]

const defaultMenu = {
  before: `*〔 llı INFO USER ıll 〕*
 
⛓️ *Name:* %nama
⛓️ *Tag:* %tag
⛓️ *Status:* %ryhar
⛓️ *Limit:* %limit
⛓️ *Role:* %role
⛓️ *Level:* %level [ %xp4levelup Xp For Levelup]
⛓️ *Xp:* %exp / %maxexp
⛓️ *Total Xp:* %totalexp


 *〔 llı TODAY ıll 〕*

⛓️ *Time:* %wib WIB
⛓️ *Days:* %week %weton
⛓️ *Date:* %date
⛓️ *Islamic Date:* %dateIslamic


 *〔 llı INFO ıll 〕*
 
⛓️ *Bot Name:* %me
⛓️ *Mode:* Public
⛓️ *Platform:* Linux
⛓️ *Type:* Node.Js
⛓️ *Baileys:* Multi Device
⛓️ *Uptime:* %muptime
⛓️ *Database:* %rtotalreg dari %totalreg


 *〔 llı INFO COMMAND ıll 〕*
 
 *🅟* = Premium
 *🅛* = Limit

%readmore`.trimStart(),
  header: '❏┄┅━┅┄〈 *〘 %category 〙*\n│',
    body: '┊❃ %cmd %islimit %isPremium',
  footer: '│\n┗━═┅═━━┅┄๑\n',
  after: '%wm'
}
let handler = async (m, { conn, usedPrefix: _p, __dirname, args, usedPrefix }) => {

 /**************************** TIME *********************/
let wib = moment.tz('Asia/Jakarta').format('HH:mm:ss')
let wibh = moment.tz('Asia/Jakarta').format('HH')
let wibm = moment.tz('Asia/Jakarta').format('mm')
let wibs = moment.tz('Asia/Jakarta').format('ss')
let wit = moment.tz('Asia/Jayapura').format('HH:mm:ss')
let wita = moment.tz('Asia/Makassar').format('HH:mm:ss')
let wktuwib = `${wibh} H ${wibm} M ${wibs} S`
let thummb = fs.readFileSync('./thumbnail.jpg')
let mode = global.opts['self'] ? 'Private' : 'Publik'
let _package = JSON.parse(await promises.readFile(join(__dirname, '../package.json')).catch(_ => ({}))) || {}
let { age, exp, limit, level, role, registered, money} = global.db.data.users[m.sender]
let { min, xp, max } = xpRange(level, global.multiplier)
let name = await conn.getName(m.sender)
let premium = global.db.data.users[m.sender].premiumTime
let prems = `${premium > 0 ? 'Premium': 'Free'}`
let platform = os.platform()
let vn = './media/yntkts'
//-----------TIME---------
let ucpn = `${ucapan()}`
let who = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.fromMe ? conn.user.jid : m.sender
let d = new Date(new Date + 3600000)
let locale = 'id'
// d.getTimeZoneOffset()
// Offset -420 is 18.00
// Offset0 is0.00
// Offset420 is7.00
let weton = ['Pahing', 'Pon', 'Wage', 'Kliwon', 'Legi'][Math.floor(d / 84600000) % 5]
let week = d.toLocaleDateString(locale, { weekday: 'long' })
let date = d.toLocaleDateString(locale, {
day: 'numeric',
month: 'long',
year: 'numeric'
})
let dateIslamic = Intl.DateTimeFormat(locale + '-TN-u-ca-islamic', {
day: 'numeric',
month: 'long',
year: 'numeric'
}).format(d)
let time = d.toLocaleTimeString(locale, {
hour: 'numeric',
minute: 'numeric',
second: 'numeric'
})
let _uptime = process.uptime() * 1000
let _muptime
if (process.send) {
process.send('uptime')
_muptime = await new Promise(resolve => {
process.once('message', resolve)
setTimeout(resolve, 1000)
}) * 1000
}
let muptime = clockString(_muptime)
let uptime = clockString(_uptime)

//---------------------
let nomorwa = '62895341999786'
let wm = `Pᴏᴡᴇʀ Bʏ ⬝ Whatsapp\nCʀᴇᴀᴛᴏʀ Bᴏᴛ ⬝ Renz\n⻝ 𝗗𝗮𝘁𝗲: ${week} ${date}\n⻝ 𝗧𝗶𝗺𝗲: ${wktuwib}`
let totalreg = Object.keys(global.db.data.users).length
let rtotalreg = Object.values(global.db.data.users).filter(user => user.registered == true).length
let help = Object.values(global.plugins).filter(plugin => !plugin.disabled).map(plugin => {
return {
help: Array.isArray(plugin.tags) ? plugin.help : [plugin.help],
tags: Array.isArray(plugin.tags) ? plugin.tags : [plugin.tags],
prefix: 'customPrefix' in plugin,
limit: plugin.limit,
premium: plugin.premium,
enabled: !plugin.disabled,
}
})

let totalf = Object.values(global.plugins).filter(
    (v) => v.help && v.tags
  ).length
let tags
let emot = `🌸`
let rndom = `${pickRandom(['defaultMenu', 'defmenu1'])}`
let teks = `${args[0]}`.toLowerCase()
let arrayMenu = ['all', 'main', 'game', 'rpg', 'xp', 'sticker', 'kerang', 'quotes', 'fun', 'anime', 'adminry', 'group', 'store', 'vote', 'absen', 'premium', 'anonymous', 'internet', 'downloader', 'search', 'tools', 'nulis', 'audio', 'maker', 'database', 'quran', 'owner', 'info', 'virus', 'random', 'sound', 'nsfw', 'randoms']
if (!arrayMenu.includes(teks)) teks = '404'
if (teks == 'all') tags = {
  'main': 'Main',
  'game': 'Game',
  'rpg': 'RPG Games',
  'xp': 'Exp & Limit',
  'sticker': 'Sticker',
  'kerang': 'Kerang Ajaib',
  'quotes': 'Quotes',
  'fun': 'Fun',
  'anime': 'Anime',
  'adminry': 'Admin',
  'group': 'Group',
  'store': 'Store',
  'vote': 'Voting',
  'absen': 'Absen',
  'premium': 'Premium',
  'nsfw': 'Nsfw',
  'anonymous': 'Anonymous Chat',
  'internet': 'Internet',
  'downloader': 'Downloader',
  'search': 'Searching',
  'tools': 'Tools',
  'nulis': 'MagerNulis & Logo',
  'audio': 'Audio',
  'maker': 'Maker',
  'database': 'Database',
  'quran': 'Al Quran',
  'owner': 'Owner', 
  'info': 'Info',
  'virus': 'Virtex Menu',
  'random': 'Random Sfx',
  'randoms': 'Random',
  'sound': 'Sound',
}
if (teks == 'main') tags = {
'main': 'Main'
}
if (teks == 'game') tags = {
'game': 'Game'
}
if (teks == 'rpg') tags = {
'rpg': 'RPG Games'
}
if (teks == 'xp') tags = {
'xp': 'Exp & Limit'
}
if (teks == 'sticker') tags = {
'sticker': 'Sticker'
}
if (teks == 'kerang') tags = {
'kerang': 'Kerang Ajaib'
}
if (teks == 'quotes') tags = {
'quotes': 'Quotes'
}
if (teks == 'xp') tags = {
'xp': 'Exp & Limit'
}
if (teks == 'stiker') tags = {
'sticker': 'Stiker'
}
if (teks == 'kerangajaib') tags = {
'kerang': 'Kerang Ajaib'
}
if (teks == 'quotes') tags = {
'quotes': 'Quotes'
}
if (teks == 'fun') tags = {
'fun': 'Fun'
}
if (teks == 'anime') tags = {
'anime': 'Anime'
}
if (teks == 'adminry') tags = {
'adminry': 'Admin'
}
if (teks == 'group') tags = {
'group': 'Group'
}
if (teks == 'store') tags = {
'store': 'Store'
}
if (teks == 'vote') tags = {
'vote': 'Voting'
}
if (teks == 'absen') tags = {
'absen': 'Absen'
}
if (teks == 'premium') tags = {
'premium': 'Premium'
}
if (teks == 'nsfw') tags = {
'nsfw': 'Nsfw'
}
if (teks == 'anonymous') tags = {
'anonymous': 'Anonymous Chat'
}
if (teks == 'internet') tags = {
'internet': 'Internet'
}
if (teks == 'downloader') tags = {
'downloader': 'Downloader'
}
if (teks == 'search') tags = {
'search': 'Searching'
}
if (teks == 'tools') tags = {
'tools': 'Tools'
}
if (teks == 'nulis') tags = {
'nulis': 'MagerNulis & Logo'
}
if (teks == 'audio') tags = {
'audio': 'Audio'
}
if (teks == 'maker') tags = {
'maker': 'Maker'
}
if (teks == 'database') tags = {
'database': 'Database'
}
if (teks == 'quran') tags = {
'quran': 'Al Qur\'an'
}
if (teks == 'owner') tags = {
'owner': 'Owner'
}
if (teks == 'info') tags = {
'info': 'Info'
}
if (teks == 'virus') tags = {
'virus': 'Virtex Menu'
}
 if (teks == 'random') tags = {
'random': 'Random Sfx'
}
if (teks == 'randoms') tags = {
'randoms': 'Random'
}
if (teks == 'sound') tags = {
'sound': 'Sound'
}
try {
// DEFAULT MENU
let dash = global.dashmenu
let m1 = global.dmenut
let m2 = global.dmenub
let m3 = global.dmenuf
let m4 = global.dmenub2

// COMMAND MENU
let cc = global.cmenut
let c1 = global.cmenuh
let c2 = global.cmenub
let c3 = global.cmenuf
let c4 = global.cmenua

// LOGO L P
let lprem = global.lopr
let llim = global.lolm
let tag =  `@${m.sender.split('@')[0]}`

let _mpt
if (process.send) {
process.send('uptime')
_mpt = await new Promise(resolve => {
process.once('message', resolve)
setTimeout(resolve, 1000)
}) * 1000
}
let mpt = clockString(_mpt)
const sections = [
{
title: `⃟⟣⟚⟝ ⟡ List Menu ${global.wm} ⟡ ⟞⟚⟢⃟`,
rows: [
{title: `🌸 Semua Menu`, rowId: ".? all", description: "Menampilkan Semua Menu"},
{title: `🎨 Main`, rowId: ".? main", description: "Menampilkan Main Menu"},
{title: `🎮 Game`, rowId: ".? game", description: "Menampilkan List Menu Game"},
{title: `⚔️ RPG Games`, rowId: ".? rpg", description: "Menampilkan List Menu Rpg"},
{title: `🌟 Exp & Limit`, rowId: ".? xp", description: "Menampilkan List Menu Exp & Limit"},
{title: `😻 Sticker`, rowId: ".? sticker", description: "Menampilkan List Menu Sticker"},
{title: `🧞‍♂️ Kerang Ajaib`, rowId: ".? kerang", description: "Menampilkan List Menu Kerang Ajaib"},
{title: `💌 Quotes`, rowId: ".? quotes", description: "Menampilkan List Menu Quotes"},
{title: `🎉 Fun`, rowId: ".? fun", description: "Menampilkan List Menu Fun"},
{title: `🎎 Anime`, rowId: ".? anime", description: "Menampilkan List Menu Anime"},
{title: `💬 Group`, rowId: ".? group", description: "Menampilkan List Menu Group"},
{title: `🛒 Store`, rowId: ".? store", description: "Menampilkan List Menu Store"},
{title: `🗳 Voting`, rowId: ".? vote", description: "Menampilkan List Menu Voting"},
{title: `🙌 Absen`, rowId: ".? absen", description: "Menampilkan List Menu Absen"},
{title: `🪙 Premium`, rowId: ".? premium", description: "Menampilkan List Menu Premium"},
{title: `📸 Nsfw`, rowId: ".? nsfw", description: "Menampilan List Menu Nsfw"},
{title: `👁‍🗨 Anonymous Chat`, rowId: ".? anonymous", description: "Menampilkan List Menu Anonymous"},
{title: `📡 Internet`, rowId: ".? internet", description: "Menampilkan List Menu Internet"},
{title: `🎰 Downloader`, rowId: ".? downloader", description: "Menampilkan List Menu Downloader"},
{title: `🔎 Searching`, rowId: ".? search", description: "Menampilkan List Menu Searching"},
{title: `⚙️ Tools`, rowId: ".? tools", description: "Menampilkan List Menu Tools"},
{title: `🎨 MagerNulis & Logo`, rowId: ".? nulis", description: "Menampilkan List Menu MagerNulis & Logo"},
{title: `🎧 Audio`, rowId: ".? audio", description: "Menampilkan List Menu Audio"},
{title: `🪛 Maker`, rowId: ".? maker", description: "Menampilkan List Menu Maker"},
{title: `🔐 Database`, rowId: ".? database", description: "Menampilkan Menu Database"},
{title: `💐 Al Qur\'an`, rowId: ".? quran", description: "Menampilkan List Menu Al Qur\'an"},
{title: `🧸 Owner`, rowId: ".? owner", description: "Menampilkan List Menu Owner"},
{title: `📢 Info`, rowId: ".? info", description: "Menampilan List Menu Info"},
{title: `☢️ Virtex Menu`, rowId: ".? virus", description: "Menampilan List Menu Virtex"},
{title: `🔊 Random Sfx`, rowId: ".? random", description: "Menampilan List Menu Random Sfx"},
{title: `📜 Random Menu`, rowId: ".? randoms", description: "Menampilan List Random"},
{title: `🎶 Sound`, rowId: ".? sound", description: "Menampilan List Menu Sound"},
]
}, {
title: `⃟⟣⟚⟝ ⟡ Support Me ${global.wm} ⟡ ⟞⟚⟢⃟`,
rows: [
{title: `💸 Donasi`, rowId: ".donasi", description: "Donasi Agar Saya Semangat Untuk Update Bot:)"},
{title: `⚖️ Rating Bot`, rowId: ".rate", description: "Rating Bot Saya :)"},
{title: `🛒 Sewa Bot`, rowId: ".sewa", description: "Mau Nyewa?"},
{title: `📁 Script`, rowId: ".sc", description: "Menampilkan Script Bot Ini"},
]}]
let psan = 'bagaimana kabarmu?'
let usrs = db.data.users[m.sender]
let nama = `${usrs.registered ? usrs.name : conn.getName(m.sender)}`
let ryhar = `${m.sender.split`@`[0] == nomorown ? 'Developer' : (usrs.premiumTime >= 1 ? 'Premium User' : 'Free User')}`
let fkontak = { key: { fromMe: false, participant: `0@s.whatsapp.net`, ...(m.chat ? { remoteJid: `status@broadcast` } : {}) }, message: { 'contactMessage': { 'displayName': author, 'vcard': `BEGIN:VCARD\nVERSION:3.0\nN:XL;${author},;;;\nFN:${author},\nitem1.TEL;waid=${m.sender.split('@')[0]}:${m.sender.split('@')[0]}\nitem1.X-ABLabell:Ponsel\nEND:VCARD`, 'jpegThumbnail': fs.readFileSync('./thumbnail.jpg'), thumbnail: fs.readFileSync('./thumbnail.jpg'),sendEphemeral: true}}}
let tagnya = `@${m.sender.split`@`[0]}`
let hariRayaramadan = new Date('April 21, 2023 23:59:59') 
     let sekarangg = new Date().getTime() 
     let lebih = hariRayaramadan - sekarangg 
     let harii = Math.floor( lebih / (1000 * 60 * 60 * 24)); 
     let jamm = Math.floor( lebih % (1000 * 60 * 60 * 24) / (1000 * 60 * 60)) 
     let menitt = Math.floor( lebih % (1000 * 60 * 60) / (1000 * 60)) 
     let detikk = Math.floor( lebih % (1000 * 60) / 1000) 
let fot = `Nᴏᴛᴇ!!: ᴊɪᴋᴀ ᴀɴᴅᴀ ᴍᴇɴᴇᴍᴜᴋᴀɴ ʙᴜɢ/ᴇʀʀᴏʀ ꜱɪʟᴀʜᴋᴀɴ ʟᴀᴘᴏʀᴋᴀɴ ᴘᴀᴅᴀ *ᴏᴡɴᴇʀ*`
const listMessage = {
text: `_*${ucapan()} ${tag}*_`,
footer: `${fot}`,
title: '',
mentions: [m.sender],
buttonText: 'Click!', 
sections
}
if (teks == '404') {
return conn.sendMessage(m.chat, listMessage, { quoted: m, mentions: [m.sender] }) 
}

let groups = {}
for (let tag in tags) {
groups[tag] = []
for (let plugin of help)
if (plugin.tags && plugin.tags.includes(tag))
if (plugin.help) groups[tag].push(plugin)
}
conn.menu = conn.menu ? conn.menu : {}
let before = conn.menu.before || defaultMenu.before
let header = conn.menu.header || defaultMenu.header
let body = conn.menu.body || defaultMenu.body
let footer = conn.menu.footer || defaultMenu.footer
let after = conn.menu.after || (conn.user.jid == global.conn.user.jid ? '' : `Powered by https://wa.me/${global.conn.user.jid.split`@`[0]}`) + defaultMenu.after
let _text = [
before,
...Object.keys(tags).map(tag => {
return header.replace(/%category/g, tags[tag]) + '\n' + [
...help.filter(menu => menu.tags && menu.tags.includes(tag) && menu.help).map(menu => {
return menu.help.map(help => {
return body.replace(/%cmd/g, menu.prefix ? help : '%_p' + help)
.replace(/%islimit/g, menu.limit ? llim : '')
.replace(/%isPremium/g, menu.premium ? lprem : '')
.trim()
}).join('\n')
}),
footer
].join('\n')
}),
after
].join('\n')
let text = typeof conn.menu == 'string' ? conn.menu : typeof conn.menu == 'object' ? _text : ''
let replace = {
'%': '%',
p: uptime, muptime,
me: conn.getName(conn.user.jid),
npmname: _package.name,
npmdesc: _package.description,
version: _package.version,
exp: exp - min,
maxexp: xp,
totalexp: exp,
xp4levelup: max - exp,
github: _package.homepage ? _package.homepage.url || _package.homepage : '[unknown github url]',
tag, dash,m1,m2,m3,m4,cc, c1, c2, c3, c4,lprem,llim,
ucpn,platform, wib, mode, _p, money, age, tag, name, prems, level, limit, name, weton, week, date, dateIslamic, time, totalreg, rtotalreg, role, ryhar, wit, wita, wktuwib, nama, wm,
readmore: readMore
}
text = text.replace(new RegExp(`%(${Object.keys(replace).sort((a, b) => b.length - a.length).join`|`})`, 'g'), (_, name) => '' + replace[name])
conn.sendButton(m.chat, `${ucapan()} ${usrs.registered ? usrs.name : conn.getName(m.sender)}\n`, text.trim(), MenuImg.getRandom(), [[`ꜱ ᴇ ᴡ ᴀ ʙ ᴏ ᴛ`, `${usedPrefix}sewa`], [`۪۪ᴀ ᴜ ᴛ ʜ ᴏ ʀ`, `${usedPrefix}owner`], [`ᴘ ɪ ɴ ɢ`, `${usedPrefix}ping`]], m, {mentions: [m.sender]})
} catch (e) {
conn.reply(m.chat, 'Maaf, menu sedang error', m)
throw e
}
}
handler.help = ['menu']
handler.tags = ['main']
handler.command = /^(menu|\?)$/i

handler.register = true
handler.exp = 3

export default handler

//----------- FUNCTION -------

function pickRandom(list) {
return list[Math.floor(Math.random() * list.length)]
}

const more = String.fromCharCode(8206)
const readMore = more.repeat(4001)

function clockString(ms) {
let h = isNaN(ms) ? '--' : Math.floor(ms / 3600000)
let m = isNaN(ms) ? '--' : Math.floor(ms / 60000) % 60
let s = isNaN(ms) ? '--' : Math.floor(ms / 1000) % 60
return [h, ' H ', m, ' M ', s, ' S '].map(v => v.toString().padStart(2, 0)).join('')
}
function clockStringP(ms) {
let ye = isNaN(ms) ? '--' : Math.floor(ms / 31104000000) % 10
let mo = isNaN(ms) ? '--' : Math.floor(ms / 2592000000) % 12
let d = isNaN(ms) ? '--' : Math.floor(ms / 86400000) % 30
let h = isNaN(ms) ? '--' : Math.floor(ms / 3600000) % 24
let m = isNaN(ms) ? '--' : Math.floor(ms / 60000) % 60
let s = isNaN(ms) ? '--' : Math.floor(ms / 1000) % 60
return [ye, ' *Years 🗓️*\n',mo, ' *Month 🌙*\n', d, ' *Days ☀️*\n', h, ' *Hours 🕐*\n', m, ' *Minute ⏰*\n', s, ' *Second ⏱️*'].map(v => v.toString().padStart(2, 0)).join('')
}
function ucapan() {
const time = moment.tz('Asia/Jakarta').format('HH')
let res = "Selamat Dinihari Kak,"
if (time >= 4) {
res = "Selamat Pagi Kak,"
}
if (time >= 10) {
res = "Selamat Siang Kak,"
}
if (time >= 15) {
res = "Selamat Sore Kak,"
}
if (time >= 18) {
res = "Selamat Malam Kak,"
}
return res
}
