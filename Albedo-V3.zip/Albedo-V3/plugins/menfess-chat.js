let handler = async(m, { conn, usedPrefix, command, text:q }) => {
    command = command.toLowerCase()
    conn.menfess = conn.menfess ? conn.menfess : {}
    const { body, reply, from, sender } = m;
    const desc = `*Menfess Bot*\n\n*Example :*\n ◦ ${usedPrefix}menfess 628xxxxx`
    let button = [
      { buttonId: `.accmenfess`, buttonText: { displayText: 'Terima' }, type: 1 },
      { buttonId: `.tolakmenfess`, buttonText: { displayText: 'Tolak' }, type: 1}
      ]
    let id = m.sender
    let find = Object.values(conn.menfess).find(menpes => menpes.status == 'wait')
    let roof = Object.values(conn.menfess).find(menpes => [menpes.a, menpes.b].includes(m.sender))
    
    switch(command){
      case 'menfesschat':
        if(roof) return m.reply('Kamu masih berada dalam Obrolan!')
        if(!q) throw desc;
        if(!q.startsWith('628')) throw desc
        let text = q + "@s.whatsapp.net"
        let txt = `*Menfess Chat*\n\n_Hallo, @${sender.split("@")[0]} telah mengajakmu bermain chat menfess di bot ini_\n\n*Balas pesan ini ( terima / tolak )*`
        m.reply(`*^Done, silahkan tunggu dia menerima ajakan chatmu..*`)
        conn.sendMessage(text, {text:txt,footer: wm, buttons: button,headerType: 1},{adReply: true})
        conn.menfess[id] = {
          id: id,
          a: m.sender,
          b: text,
          status: "wait",
        }
        break;
       
      case 'accmenfess':
       if(!roof) return m.reply("Kamu belum memulai menfess..")
       try {
        find.b = m.sender
        find.status = 'chatting'
        conn.menfess[find.id] = {...find}
        await conn.sendMessage(find.a,{text: `_Done, sekarang anda bisa chat lewat bot dengan dia.._\n\n*NOTE : Jika ingin berhenti dari menfess, silahkan ketik _.stopmenfess_ Untuk hapus session kalian..*`},{adReply: true})
        await conn.reply(m.chat, `_Done, sekarang anda bisa chat lewat bot dengan dia.._\n\n*NOTE : Jika ingin berhenti dari menfess, silahkan ketik _.stopmenfess_ Untuk hapus session kalian..* `, null)
       } catch (e){
         throw e
       }
        break

      case 'tolakmenfess':
        if(!roof) return m.reply("Kamu belum memulai menfess..")
        await conn.sendMessage(find.a, {text: `Yahhh :( Dia Menolak bermain menfess.._\n\n Sabar Ya banh :v`,withTag: true})
        conn.reply(m.chat, `Done, menolak menfess chat`, null)
        delete conn.menfess[find.id]
        return !0
        break
    }
}

handler.command = ['menfesschat','tolakmenfess','accmenfess']
handler.private = true
handler.tags = ['anonymous']
handler.help = ['tolakmenfess','accmenfess']
export default handler

//Wm By Kimimaru
//github: https://github.com/K1mimaru