import fetch from 'node-fetch'
let handler = async (m, { text, command, usedPrefix }) => {
	try {
	if (!text) throw 'Apa Pertanyaannya?'
    let f = await fetch(`https://api.lolhuman.xyz/api/brainly?apikey=${global.lolkey}&query=${text}`)
    let xx = await f.json()
    let v = xx.result
    let teks = v.map(v => {
    return `  
*Pertanyaan:*
${v.question.content}

*Jawaban:*
${v.answer.content}
      `.trim()
  }).filter(v => v).join('\n\n\n')
  await conn.sendButton(m.chat, teks, wm, null, [
                ['Search!', `${usedPrefix + command}`]
            ], m)
} catch (e) {
    m.reply('Tidak Dapat Menemukan Jawaban...')
  }
}
handler.help = ['brainly <teks>']
handler.tags = ['internet']
handler.command = /^brainly$/i
export default handler