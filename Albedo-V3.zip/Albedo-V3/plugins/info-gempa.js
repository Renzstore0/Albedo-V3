import fetch from 'node-fetch'
let handler = async(m, { conn, text, usedPrefix }) => {
  let res = await (await fetch('https://api.lolhuman.xyz/api/infogempa?apikey=RyHar'))
  if (!res.ok) throw await res.text()
  let json = await res.json()
  if(!json.result) throw json
  let { map, waktu, magnitude, kedalaman, koordinat, lokasi, potensi } = await json.result
  conn.sendButton(m.chat, `*${htki} INFO GEMPA ${htka}*\n*🕢Waktu:* ${waktu}\n*🎛Magnitude:* ${magnitude}\n*🌊Kedalaman:* ${kedalaman}\n*📡Koordinat:* ${koordinat}\n*📌Lokasi:* ${lokasi}`, wm, await(await fetch(map)).buffer(), [['M E N U', `${usedPrefix}menu`]], m)
}
handler.help = ['infogempa']
handler.tags = ['internet', 'info']
handler.command = /^(infogempa)$/i
handler.limit = true
export default handler